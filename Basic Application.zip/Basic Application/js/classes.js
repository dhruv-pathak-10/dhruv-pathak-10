// Mock data for classes
let classes = [
    {
        id: 1,
        name: "10A",
        teacher: "Mr. Anderson",
        roomNumber: "101",
        section: "A",
        students: [
            { rollNo: "2025001", name: "John Doe", contact: "1234567890" },
            { rollNo: "2025002", name: "Jane Smith", contact: "9876543210" }
        ],
        schedule: [
            {
                time: "8:00 AM - 9:00 AM",
                monday: "Mathematics",
                tuesday: "Physics",
                wednesday: "Chemistry",
                thursday: "English",
                friday: "Computer Science"
            },
            // Add more schedule rows
        ],
        subjects: [
            { name: "Mathematics", teacher: "Mr. Anderson", hoursPerWeek: 6 },
            { name: "Physics", teacher: "Mrs. Thompson", hoursPerWeek: 4 },
            { name: "Chemistry", teacher: "Mr. Wilson", hoursPerWeek: 4 }
        ]
    },
    // Add more classes
];

// Mock data for teachers
const teachers = [
    "Mr. Anderson",
    "Mrs. Thompson",
    "Mr. Wilson",
    "Ms. Davis",
    "Mr. Brown"
];

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', () => {
    // Populate teachers dropdown
    const teacherSelect = document.getElementById('classTeacher');
    teachers.forEach(teacher => {
        const option = document.createElement('option');
        option.value = teacher;
        option.textContent = teacher;
        teacherSelect.appendChild(option);
    });

    // Load classes
    loadClasses();
});

// Load classes into grid
function loadClasses() {
    const grid = document.getElementById('classesGrid');
    grid.innerHTML = '';

    classes.forEach(classItem => {
        const card = document.createElement('div');
        card.className = 'col-md-4 mb-4';
        card.innerHTML = `
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">${classItem.name}</h5>
                    <p class="card-text">
                        <strong>Teacher:</strong> ${classItem.teacher}<br>
                        <strong>Room:</strong> ${classItem.roomNumber}<br>
                        <strong>Section:</strong> ${classItem.section}
                    </p>
                    <div class="d-flex justify-content-between">
                        <button class="btn btn-primary" onclick="viewClass(${classItem.id})">
                            <i class="fas fa-eye me-2"></i>View Details
                        </button>
                        <button class="btn btn-danger" onclick="deleteClass(${classItem.id})">
                            <i class="fas fa-trash me-2"></i>Delete
                        </button>
                    </div>
                </div>
            </div>
        `;
        grid.appendChild(card);
    });
}

// Add new class
function addClass() {
    const newClass = {
        id: classes.length + 1,
        name: document.getElementById('className').value,
        teacher: document.getElementById('classTeacher').value,
        roomNumber: document.getElementById('roomNumber').value,
        section: document.getElementById('section').value,
        students: [],
        schedule: [],
        subjects: []
    };

    // Validate required fields
    if (!newClass.name || !newClass.teacher || !newClass.roomNumber || !newClass.section) {
        alert('Please fill in all required fields');
        return;
    }

    // Add to classes array
    classes.push(newClass);

    // Reload classes grid
    loadClasses();

    // Close modal and reset form
    $('#addClassModal').modal('hide');
    document.getElementById('addClassForm').reset();
}

// View class details
function viewClass(id) {
    const classItem = classes.find(c => c.id === id);
    if (classItem) {
        // Load students table
        const studentsTable = document.getElementById('classStudentsTable').getElementsByTagName('tbody')[0];
        studentsTable.innerHTML = '';
        classItem.students.forEach(student => {
            const row = studentsTable.insertRow();
            row.innerHTML = `
                <td>${student.rollNo}</td>
                <td>${student.name}</td>
                <td>${student.contact}</td>
            `;
        });

        // Load schedule table
        const scheduleTable = document.getElementById('scheduleTable');
        scheduleTable.innerHTML = '';
        classItem.schedule.forEach(scheduleItem => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${scheduleItem.time}</td>
                <td>${scheduleItem.monday}</td>
                <td>${scheduleItem.tuesday}</td>
                <td>${scheduleItem.wednesday}</td>
                <td>${scheduleItem.thursday}</td>
                <td>${scheduleItem.friday}</td>
            `;
            scheduleTable.appendChild(row);
        });

        // Load subjects table
        const subjectsTable = document.getElementById('subjectsTable').getElementsByTagName('tbody')[0];
        subjectsTable.innerHTML = '';
        classItem.subjects.forEach(subject => {
            const row = subjectsTable.insertRow();
            row.innerHTML = `
                <td>${subject.name}</td>
                <td>${subject.teacher}</td>
                <td>${subject.hoursPerWeek}</td>
            `;
        });

        // Show modal
        $('#viewClassModal').modal('show');
    }
}

// Delete class
function deleteClass(id) {
    if (confirm('Are you sure you want to delete this class?')) {
        classes = classes.filter(c => c.id !== id);
        loadClasses();
    }
}
