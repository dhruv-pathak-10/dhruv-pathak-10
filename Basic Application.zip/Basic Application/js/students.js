// Mock data for students
let students = [
    {
        id: 1,
        rollNo: "2025001",
        name: "John Doe",
        class: "10A",
        gender: "Male",
        dob: "2010-05-15",
        contact: "1234567890",
        address: "123 School Street"
    },
    {
        id: 2,
        rollNo: "2025002",
        name: "Jane Smith",
        class: "10A",
        gender: "Female",
        dob: "2010-06-20",
        contact: "9876543210",
        address: "456 College Road"
    }
];

// Mock data for classes
const classes = ["9A", "9B", "10A", "10B", "11A", "11B", "12A", "12B"];

// Initialize DataTable
let studentsTable;

document.addEventListener('DOMContentLoaded', () => {
    // Populate classes dropdown
    const classSelect = document.getElementById('studentClass');
    classes.forEach(className => {
        const option = document.createElement('option');
        option.value = className;
        option.textContent = className;
        classSelect.appendChild(option);
    });

    // Initialize DataTable
    studentsTable = $('#studentsTable').DataTable({
        data: students,
        columns: [
            { data: 'rollNo' },
            { data: 'name' },
            { data: 'class' },
            { data: 'gender' },
            { data: 'contact' },
            {
                data: null,
                render: function(data, type, row) {
                    return `
                        <button class="btn btn-sm btn-primary me-2" onclick="editStudent(${row.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-sm btn-danger" onclick="deleteStudent(${row.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    `;
                }
            }
        ]
    });
});

// Add new student
function addStudent() {
    const newStudent = {
        id: students.length + 1,
        rollNo: document.getElementById('rollNo').value,
        name: document.getElementById('studentName').value,
        class: document.getElementById('studentClass').value,
        gender: document.getElementById('studentGender').value,
        dob: document.getElementById('dob').value,
        contact: document.getElementById('contact').value,
        address: document.getElementById('address').value
    };

    // Validate required fields
    if (!newStudent.rollNo || !newStudent.name || !newStudent.class) {
        alert('Please fill in all required fields');
        return;
    }

    // Add to students array
    students.push(newStudent);

    // Update DataTable
    studentsTable.row.add(newStudent).draw();

    // Close modal and reset form
    $('#addStudentModal').modal('hide');
    document.getElementById('addStudentForm').reset();
}

// Edit student
function editStudent(id) {
    const student = students.find(s => s.id === id);
    if (student) {
        // Populate edit form
        document.getElementById('editStudentId').value = student.id;
        // Add code to populate other fields

        // Show edit modal
        $('#editStudentModal').modal('show');
    }
}

// Update student
function updateStudent() {
    const id = parseInt(document.getElementById('editStudentId').value);
    const studentIndex = students.findIndex(s => s.id === id);

    if (studentIndex !== -1) {
        // Update student data
        students[studentIndex] = {
            ...students[studentIndex],
            // Add code to update other fields
        };

        // Update DataTable
        studentsTable.clear().rows.add(students).draw();

        // Close modal
        $('#editStudentModal').modal('hide');
    }
}

// Delete student
function deleteStudent(id) {
    if (confirm('Are you sure you want to delete this student?')) {
        students = students.filter(s => s.id !== id);
        studentsTable.clear().rows.add(students).draw();
    }
}

// Search functionality
document.getElementById('searchStudent').addEventListener('keyup', function(e) {
    studentsTable.search(e.target.value).draw();
});
