// Mock data for grades
const gradesData = [
    {
        id: "S001",
        name: "John Doe",
        grades: {
            mathematics: 92,
            science: 88,
            english: 90,
            history: 85
        }
    },
    {
        id: "S002",
        name: "Jane Smith",
        grades: {
            mathematics: 95,
            science: 92,
            english: 88,
            history: 90
        }
    },
    {
        id: "S003",
        name: "Mike Johnson",
        grades: {
            mathematics: 78,
            science: 82,
            english: 85,
            history: 80
        }
    }
];

// Initialize dashboard
document.addEventListener('DOMContentLoaded', () => {
    loadGrades();
    initializeCharts();
});

// Load grades into table
function loadGrades() {
    const tableBody = document.getElementById('gradesTable');
    if (!tableBody) return;

    tableBody.innerHTML = '';
    
    gradesData.forEach(student => {
        const average = calculateAverage(student.grades);
        const grade = getLetterGrade(average);
        const row = document.createElement('tr');
        
        row.innerHTML = `
            <td>${student.id}</td>
            <td>
                <div class="d-flex align-items-center">
                    <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(student.name)}&background=random" 
                         class="rounded-circle me-2" 
                         width="32" height="32" 
                         alt="${student.name}">
                    ${student.name}
                </div>
            </td>
            <td>${formatGrade(student.grades.mathematics)}</td>
            <td>${formatGrade(student.grades.science)}</td>
            <td>${formatGrade(student.grades.english)}</td>
            <td>${formatGrade(student.grades.history)}</td>
            <td><strong>${average}%</strong></td>
            <td><span class="badge bg-${getGradeColor(grade)}">${grade}</span></td>
            <td>
                <button class="btn btn-sm btn-outline-primary me-1" onclick="editGrade('${student.id}')">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteGrade('${student.id}')">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        
        tableBody.appendChild(row);
    });
}

// Initialize charts
function initializeCharts() {
    initializeGradeDistribution();
    initializeSubjectPerformance();
}

// Initialize grade distribution chart
function initializeGradeDistribution() {
    const ctx = document.getElementById('gradeDistribution');
    if (!ctx) return;

    const gradeRanges = {
        'A': 0, 'B': 0, 'C': 0, 'D': 0, 'F': 0
    };

    gradesData.forEach(student => {
        const average = calculateAverage(student.grades);
        const grade = getLetterGrade(average);
        gradeRanges[grade]++;
    });

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: Object.keys(gradeRanges),
            datasets: [{
                label: 'Number of Students',
                data: Object.values(gradeRanges),
                backgroundColor: [
                    '#28a745', '#17a2b8', '#ffc107', '#fd7e14', '#dc3545'
                ]
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                title: {
                    display: true,
                    text: 'Grade Distribution'
                }
            }
        }
    });
}

// Initialize subject performance chart
function initializeSubjectPerformance() {
    const ctx = document.getElementById('subjectPerformance');
    if (!ctx) return;

    const subjects = ['Mathematics', 'Science', 'English', 'History'];
    const averages = subjects.map(subject => {
        const subjectKey = subject.toLowerCase();
        return calculateSubjectAverage(subjectKey);
    });

    new Chart(ctx, {
        type: 'radar',
        data: {
            labels: subjects,
            datasets: [{
                label: 'Class Average',
                data: averages,
                fill: true,
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgb(54, 162, 235)',
                pointBackgroundColor: 'rgb(54, 162, 235)',
                pointBorderColor: '#fff',
                pointHoverBackgroundColor: '#fff',
                pointHoverBorderColor: 'rgb(54, 162, 235)'
            }]
        },
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    text: 'Subject Performance'
                }
            },
            scales: {
                r: {
                    min: 0,
                    max: 100,
                    beginAtZero: true
                }
            }
        }
    });
}

// Utility functions
function calculateAverage(grades) {
    const values = Object.values(grades);
    const sum = values.reduce((a, b) => a + b, 0);
    return Math.round(sum / values.length);
}

function calculateSubjectAverage(subject) {
    const sum = gradesData.reduce((acc, student) => acc + student.grades[subject], 0);
    return Math.round(sum / gradesData.length);
}

function getLetterGrade(score) {
    if (score >= 90) return 'A';
    if (score >= 80) return 'B';
    if (score >= 70) return 'C';
    if (score >= 60) return 'D';
    return 'F';
}

function getGradeColor(grade) {
    const colors = {
        'A': 'success',
        'B': 'info',
        'C': 'warning',
        'D': 'orange',
        'F': 'danger'
    };
    return colors[grade] || 'secondary';
}

function formatGrade(grade) {
    return `<span class="text-${getGradeColor(getLetterGrade(grade))}">${grade}%</span>`;
}

// Grade management functions
function editGrade(studentId) {
    const student = gradesData.find(s => s.id === studentId);
    if (!student) return;
    
    // Implement edit functionality
    console.log('Editing grades for:', student);
}

function deleteGrade(studentId) {
    const index = gradesData.findIndex(s => s.id === studentId);
    if (index !== -1) {
        gradesData.splice(index, 1);
        loadGrades();
        initializeCharts();
    }
}

// Handle form submission
document.getElementById('saveGrade')?.addEventListener('click', () => {
    const form = document.getElementById('addGradeForm');
    if (!form) return;

    const formData = new FormData(form);
    // Implement save functionality
    console.log('Saving grade:', Object.fromEntries(formData));
    
    // Close modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('addGradeModal'));
    modal?.hide();
    form.reset();
});
