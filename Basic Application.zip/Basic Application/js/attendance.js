// Mock data for attendance records
let attendanceRecords = [
    {
        date: '2025-01-28',
        class: '10A',
        subject: 'Mathematics',
        records: [
            { rollNo: '2025001', name: 'John Doe', status: 'present', remarks: '' },
            { rollNo: '2025002', name: 'Jane Smith', status: 'absent', remarks: 'Sick leave' }
        ]
    }
];

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', () => {
    // Set default date to today
    document.getElementById('attendanceDate').valueAsDate = new Date();
    
    // Load classes into dropdowns
    loadClassesIntoDropdowns();
});

// Load classes into all class dropdowns
function loadClassesIntoDropdowns() {
    const classOptions = classes.map(c => `<option value="${c.name}">${c.name}</option>`).join('');
    
    // For attendance form
    document.getElementById('classSelect').innerHTML += classOptions;
    
    // For report form
    document.getElementById('reportClassSelect').innerHTML += classOptions;
}

// Load students when class is selected
function loadStudents() {
    const selectedClass = document.getElementById('classSelect').value;
    const classData = classes.find(c => c.name === selectedClass);
    
    if (classData) {
        // Load subjects for the selected class
        const subjectSelect = document.getElementById('subjectSelect');
        subjectSelect.innerHTML = '<option value="">Select Subject</option>';
        classData.subjects.forEach(subject => {
            subjectSelect.innerHTML += `<option value="${subject.name}">${subject.name}</option>`;
        });
    }
}

// Load attendance sheet
function loadAttendanceSheet() {
    const selectedClass = document.getElementById('classSelect').value;
    const selectedDate = document.getElementById('attendanceDate').value;
    const selectedSubject = document.getElementById('subjectSelect').value;
    
    if (!selectedClass || !selectedDate || !selectedSubject) {
        alert('Please select all required fields');
        return;
    }
    
    const classData = classes.find(c => c.name === selectedClass);
    if (!classData) return;
    
    // Check if attendance already exists for this date and subject
    const existingAttendance = attendanceRecords.find(
        record => record.date === selectedDate && 
                 record.class === selectedClass && 
                 record.subject === selectedSubject
    );
    
    const tableBody = document.getElementById('attendanceTableBody');
    tableBody.innerHTML = '';
    
    classData.students.forEach(student => {
        const existingRecord = existingAttendance?.records.find(r => r.rollNo === student.rollNo);
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${student.rollNo}</td>
            <td>${student.name}</td>
            <td>
                <select class="form-control" name="status_${student.rollNo}">
                    <option value="present" ${existingRecord?.status === 'present' ? 'selected' : ''}>Present</option>
                    <option value="absent" ${existingRecord?.status === 'absent' ? 'selected' : ''}>Absent</option>
                    <option value="late" ${existingRecord?.status === 'late' ? 'selected' : ''}>Late</option>
                </select>
            </td>
            <td>
                <input type="text" class="form-control" name="remarks_${student.rollNo}" 
                       value="${existingRecord?.remarks || ''}">
            </td>
        `;
        tableBody.appendChild(row);
    });
    
    document.getElementById('attendanceSheet').style.display = 'block';
}

// Save attendance
function saveAttendance() {
    const selectedClass = document.getElementById('classSelect').value;
    const selectedDate = document.getElementById('attendanceDate').value;
    const selectedSubject = document.getElementById('subjectSelect').value;
    
    const classData = classes.find(c => c.name === selectedClass);
    if (!classData) return;
    
    // Remove existing attendance record if any
    attendanceRecords = attendanceRecords.filter(
        record => !(record.date === selectedDate && 
                   record.class === selectedClass && 
                   record.subject === selectedSubject)
    );
    
    // Create new attendance record
    const newRecord = {
        date: selectedDate,
        class: selectedClass,
        subject: selectedSubject,
        records: []
    };
    
    classData.students.forEach(student => {
        newRecord.records.push({
            rollNo: student.rollNo,
            name: student.name,
            status: document.querySelector(`select[name="status_${student.rollNo}"]`).value,
            remarks: document.querySelector(`input[name="remarks_${student.rollNo}"]`).value
        });
    });
    
    attendanceRecords.push(newRecord);
    alert('Attendance saved successfully!');
}

// Generate attendance report
function generateReport() {
    const selectedClass = document.getElementById('reportClassSelect').value;
    const selectedMonth = document.getElementById('reportMonth').value;
    const selectedStudent = document.getElementById('reportStudentSelect').value;
    
    if (!selectedClass || !selectedMonth) {
        alert('Please select class and month');
        return;
    }
    
    const reportContainer = document.getElementById('attendanceReport');
    
    // Filter records for selected class and month
    const monthRecords = attendanceRecords.filter(record => {
        return record.class === selectedClass && record.date.startsWith(selectedMonth);
    });
    
    if (monthRecords.length === 0) {
        reportContainer.innerHTML = '<div class="alert alert-info">No attendance records found for selected criteria</div>';
        return;
    }
    
    // Generate report HTML
    let reportHtml = `
        <h6 class="mt-4">Attendance Report for ${selectedClass} - ${selectedMonth}</h6>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Roll No</th>
                        <th>Name</th>
                        <th>Present Days</th>
                        <th>Absent Days</th>
                        <th>Late Days</th>
                        <th>Attendance %</th>
                    </tr>
                </thead>
                <tbody>
    `;
    
    // Calculate statistics for each student
    const classData = classes.find(c => c.name === selectedClass);
    if (!classData) return;
    
    classData.students.forEach(student => {
        if (selectedStudent && student.rollNo !== selectedStudent) return;
        
        let presentCount = 0;
        let absentCount = 0;
        let lateCount = 0;
        
        monthRecords.forEach(record => {
            const studentRecord = record.records.find(r => r.rollNo === student.rollNo);
            if (studentRecord) {
                switch (studentRecord.status) {
                    case 'present': presentCount++; break;
                    case 'absent': absentCount++; break;
                    case 'late': lateCount++; break;
                }
            }
        });
        
        const totalDays = monthRecords.length;
        const attendancePercentage = ((presentCount + lateCount) / totalDays * 100).toFixed(2);
        
        reportHtml += `
            <tr>
                <td>${student.rollNo}</td>
                <td>${student.name}</td>
                <td>${presentCount}</td>
                <td>${absentCount}</td>
                <td>${lateCount}</td>
                <td>${attendancePercentage}%</td>
            </tr>
        `;
    });
    
    reportHtml += '</tbody></table></div>';
    reportContainer.innerHTML = reportHtml;
}
