// Messages System JavaScript

// Sample data structure for chats and messages
let chats = [
    {
        id: 1,
        participants: ['Teacher', 'Student'],
        name: 'Class Discussion',
        messages: [
            {
                sender: 'Teacher',
                content: 'Hello class!',
                timestamp: new Date('2025-01-28T10:00:00')
            }
        ]
    }
];

let currentUser = 'Teacher'; // This would normally come from authentication
let currentChat = null;

// Initialize the messaging system
document.addEventListener('DOMContentLoaded', function() {
    displayChats();
    setupEventListeners();
});

// Setup all event listeners
function setupEventListeners() {
    // New message form submission
    document.getElementById('messageForm')?.addEventListener('submit', handleSendMessage);
    
    // New chat creation
    document.getElementById('newChatForm')?.addEventListener('submit', handleNewChat);
    
    // Add participants form
    document.getElementById('addParticipantsForm')?.addEventListener('submit', handleAddParticipants);
    
    // Search functionality
    document.getElementById('searchChats')?.addEventListener('input', handleSearch);
}

// Display all chats in the sidebar
function displayChats(filteredChats = chats) {
    const chatList = document.getElementById('chatList');
    if (!chatList) return;
    
    chatList.innerHTML = '';
    
    filteredChats.forEach(chat => {
        const lastMessage = chat.messages[chat.messages.length - 1];
        const chatItem = `
            <div class="chat-item ${currentChat?.id === chat.id ? 'active' : ''}" 
                 onclick="selectChat(${chat.id})">
                <h6 class="mb-1">${chat.name}</h6>
                <small class="text-muted">
                    ${lastMessage ? lastMessage.sender + ': ' + lastMessage.content : 'No messages yet'}
                </small>
            </div>
        `;
        chatList.innerHTML += chatItem;
    });
}

// Display messages for the selected chat
function displayMessages(chatId) {
    const messageList = document.getElementById('messageList');
    if (!messageList) return;
    
    const chat = chats.find(c => c.id === chatId);
    if (!chat) return;
    
    messageList.innerHTML = '';
    
    chat.messages.forEach(message => {
        const isCurrentUser = message.sender === currentUser;
        const messageHtml = `
            <div class="message ${isCurrentUser ? 'sent' : 'received'}">
                <div class="card ${isCurrentUser ? 'bg-primary text-white' : 'bg-light'}">
                    <div class="card-body">
                        <h6 class="card-subtitle mb-1">${message.sender}</h6>
                        <p class="card-text mb-1">${message.content}</p>
                        <small class="${isCurrentUser ? 'text-white' : 'text-muted'}">
                            ${message.timestamp.toLocaleTimeString()}
                        </small>
                    </div>
                </div>
            </div>
        `;
        messageList.innerHTML += messageHtml;
    });
    
    // Scroll to bottom
    messageList.scrollTop = messageList.scrollHeight;
}

// Select a chat to display
function selectChat(chatId) {
    currentChat = chats.find(c => c.id === chatId);
    displayChats();
    displayMessages(chatId);
    
    // Enable/disable message input
    const messageInput = document.getElementById('messageInput');
    const sendButton = document.getElementById('sendButton');
    if (messageInput && sendButton) {
        messageInput.disabled = !currentChat;
        sendButton.disabled = !currentChat;
    }
}

// Handle sending a new message
function handleSendMessage(e) {
    e.preventDefault();
    if (!currentChat) return;
    
    const messageInput = document.getElementById('messageInput');
    const content = messageInput.value.trim();
    
    if (content) {
        const newMessage = {
            sender: currentUser,
            content: content,
            timestamp: new Date()
        };
        
        currentChat.messages.push(newMessage);
        displayMessages(currentChat.id);
        messageInput.value = '';
    }
}

// Handle creating a new chat
function handleNewChat(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const newChat = {
        id: chats.length + 1,
        name: formData.get('chatName'),
        participants: [currentUser],
        messages: []
    };
    
    chats.push(newChat);
    displayChats();
    selectChat(newChat.id);
    
    // Close modal
    bootstrap.Modal.getInstance(document.getElementById('newMessageModal')).hide();
    e.target.reset();
}

// Handle adding participants to a chat
function handleAddParticipants(e) {
    e.preventDefault();
    if (!currentChat) return;
    
    const formData = new FormData(e.target);
    const newParticipant = formData.get('participant');
    
    if (newParticipant && !currentChat.participants.includes(newParticipant)) {
        currentChat.participants.push(newParticipant);
        displayChats();
        
        // Add system message
        currentChat.messages.push({
            sender: 'System',
            content: `${newParticipant} has been added to the chat`,
            timestamp: new Date()
        });
        displayMessages(currentChat.id);
    }
    
    // Close modal
    bootstrap.Modal.getInstance(document.getElementById('addParticipantsModal')).hide();
    e.target.reset();
}

// Handle chat search
function handleSearch(e) {
    const searchTerm = e.target.value.toLowerCase();
    const filteredChats = chats.filter(chat => 
        chat.name.toLowerCase().includes(searchTerm) ||
        chat.participants.some(p => p.toLowerCase().includes(searchTerm))
    );
    displayChats(filteredChats);
}
