// Student Performance Analytics

class StudentPerformanceAnalytics {
    constructor() {
        this.charts = {};
    }

    // Initialize all charts for student performance
    initializeCharts() {
        this.initializePerformanceTrendChart();
        this.initializeSubjectComparisonChart();
        this.initializeAttendanceCorrelationChart();
        this.initializeClassRankingChart();
    }

    // Performance Trend Chart
    initializePerformanceTrendChart() {
        const ctx = document.getElementById('performanceTrendChart').getContext('2d');
        this.charts.performanceTrend = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [], // Will be populated with exam dates
                datasets: [{
                    label: 'Student Performance',
                    data: [], // Will be populated with performance data
                    borderColor: '#4e73df',
                    tension: 0.1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Performance Trend Over Time'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }

    // Subject Comparison Chart
    initializeSubjectComparisonChart() {
        const ctx = document.getElementById('subjectComparisonChart').getContext('2d');
        this.charts.subjectComparison = new Chart(ctx, {
            type: 'radar',
            data: {
                labels: [], // Will be populated with subject names
                datasets: [{
                    label: 'Student Performance',
                    data: [], // Will be populated with subject-wise performance
                    backgroundColor: 'rgba(78, 115, 223, 0.2)',
                    borderColor: '#4e73df',
                    pointBackgroundColor: '#4e73df'
                }, {
                    label: 'Class Average',
                    data: [], // Will be populated with class averages
                    backgroundColor: 'rgba(28, 200, 138, 0.2)',
                    borderColor: '#1cc88a',
                    pointBackgroundColor: '#1cc88a'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Subject-wise Performance Comparison'
                    }
                },
                scales: {
                    r: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }

    // Attendance Correlation Chart
    initializeAttendanceCorrelationChart() {
        const ctx = document.getElementById('attendanceCorrelationChart').getContext('2d');
        this.charts.attendanceCorrelation = new Chart(ctx, {
            type: 'scatter',
            data: {
                datasets: [{
                    label: 'Attendance vs Performance',
                    data: [], // Will be populated with attendance-performance correlation data
                    backgroundColor: '#4e73df'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Attendance-Performance Correlation'
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Attendance %'
                        },
                        beginAtZero: true,
                        max: 100
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Performance %'
                        },
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }

    // Class Ranking Chart
    initializeClassRankingChart() {
        const ctx = document.getElementById('classRankingChart').getContext('2d');
        this.charts.classRanking = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: [], // Will be populated with student names/IDs
                datasets: [{
                    label: 'Overall Performance',
                    data: [], // Will be populated with performance data
                    backgroundColor: '#4e73df'
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    title: {
                        display: true,
                        text: 'Class Ranking'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100
                    }
                }
            }
        });
    }

    // Update performance trend data
    updatePerformanceTrend(studentId, examData) {
        const dates = examData.map(exam => exam.date);
        const scores = examData.map(exam => exam.score);

        this.charts.performanceTrend.data.labels = dates;
        this.charts.performanceTrend.data.datasets[0].data = scores;
        this.charts.performanceTrend.update();
    }

    // Update subject comparison data
    updateSubjectComparison(studentData, classAverages) {
        const subjects = Object.keys(studentData);
        const studentScores = Object.values(studentData);
        const averageScores = subjects.map(subject => classAverages[subject]);

        this.charts.subjectComparison.data.labels = subjects;
        this.charts.subjectComparison.data.datasets[0].data = studentScores;
        this.charts.subjectComparison.data.datasets[1].data = averageScores;
        this.charts.subjectComparison.update();
    }

    // Update attendance correlation data
    updateAttendanceCorrelation(correlationData) {
        this.charts.attendanceCorrelation.data.datasets[0].data = correlationData;
        this.charts.attendanceCorrelation.update();
    }

    // Update class ranking data
    updateClassRanking(rankingData) {
        const students = rankingData.map(student => student.name);
        const scores = rankingData.map(student => student.score);

        this.charts.classRanking.data.labels = students;
        this.charts.classRanking.data.datasets[0].data = scores;
        this.charts.classRanking.update();
    }

    // Calculate performance predictions
    calculatePredictions(historicalData) {
        // Simple linear regression for prediction
        const n = historicalData.length;
        let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
        
        historicalData.forEach((data, index) => {
            sumX += index;
            sumY += data.score;
            sumXY += index * data.score;
            sumXX += index * index;
        });

        const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
        const intercept = (sumY - slope * sumX) / n;

        // Predict next value
        const nextPrediction = slope * n + intercept;

        return {
            predictedScore: Math.min(100, Math.max(0, nextPrediction)),
            trend: slope > 0 ? 'improving' : slope < 0 ? 'declining' : 'stable'
        };
    }

    // Generate performance insights
    generateInsights(studentData) {
        const insights = {
            strengths: [],
            weaknesses: [],
            recommendations: []
        };

        // Analyze subject performance
        Object.entries(studentData.subjectScores).forEach(([subject, score]) => {
            if (score >= 80) {
                insights.strengths.push(`Strong performance in ${subject}`);
            } else if (score < 60) {
                insights.weaknesses.push(`Needs improvement in ${subject}`);
                insights.recommendations.push(`Consider additional support for ${subject}`);
            }
        });

        // Analyze attendance impact
        if (studentData.attendance < 80) {
            insights.weaknesses.push('Low attendance may be affecting performance');
            insights.recommendations.push('Improve class attendance for better results');
        }

        return insights;
    }
}

// Export the analytics class
export default StudentPerformanceAnalytics;
