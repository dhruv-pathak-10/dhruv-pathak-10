// Mock data for teachers
const teachers = [
    {
        id: "T001",
        name: "Dr. Sarah Johnson",
        subject: "Mathematics",
        email: "sarah.j@school.com",
        phone: "+1-555-0123",
        classes: ["9", "10"],
        status: "Active"
    },
    {
        id: "T002",
        name: "Mr. James Smith",
        subject: "Physics",
        email: "james.s@school.com",
        phone: "+1-555-0124",
        classes: ["8", "9", "10"],
        status: "Active"
    },
    {
        id: "T003",
        name: "Mrs. Emily Brown",
        subject: "English",
        email: "emily.b@school.com",
        phone: "+1-555-0125",
        classes: ["6", "7", "8"],
        status: "Active"
    }
];

// Load teachers data
function loadTeachers() {
    const tableBody = document.getElementById('teachersTable');
    if (!tableBody) return;

    tableBody.innerHTML = '';
    teachers.forEach(teacher => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${teacher.id}</td>
            <td>
                <div class="d-flex align-items-center">
                    <img src="https://ui-avatars.com/api/?name=${encodeURIComponent(teacher.name)}&background=random" 
                         class="rounded-circle me-2" 
                         width="32" height="32" 
                         alt="${teacher.name}">
                    <div>
                        ${teacher.name}
                        <div class="small text-muted">${teacher.email}</div>
                    </div>
                </div>
            </td>
            <td>${teacher.subject}</td>
            <td>${teacher.phone}</td>
            <td>${teacher.classes.map(c => `Class ${c}`).join(', ')}</td>
            <td><span class="badge bg-success">${teacher.status}</span></td>
            <td>
                <button class="btn btn-sm btn-outline-primary me-1" onclick="editTeacher('${teacher.id}')">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="btn btn-sm btn-outline-danger" onclick="deleteTeacher('${teacher.id}')">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

// Add new teacher
function addTeacher(teacherData) {
    const newId = 'T' + String(teachers.length + 1).padStart(3, '0');
    const newTeacher = {
        id: newId,
        ...teacherData,
        status: 'Active'
    };
    teachers.push(newTeacher);
    loadTeachers();
}

// Edit teacher
function editTeacher(teacherId) {
    const teacher = teachers.find(t => t.id === teacherId);
    if (!teacher) return;
    
    // Implement edit functionality
    console.log('Editing teacher:', teacher);
}

// Delete teacher
function deleteTeacher(teacherId) {
    const index = teachers.findIndex(t => t.id === teacherId);
    if (index !== -1) {
        teachers.splice(index, 1);
        loadTeachers();
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    loadTeachers();

    // Handle form submission
    const saveButton = document.getElementById('saveTeacher');
    if (saveButton) {
        saveButton.addEventListener('click', () => {
            const form = document.getElementById('addTeacherForm');
            const formData = new FormData(form);
            const teacherData = {
                name: formData.get('name'),
                subject: formData.get('subject'),
                email: formData.get('email'),
                phone: formData.get('phone'),
                classes: Array.from(formData.getAll('classes'))
            };
            addTeacher(teacherData);
            
            // Close modal and reset form
            const modal = bootstrap.Modal.getInstance(document.getElementById('addTeacherModal'));
            modal.hide();
            form.reset();
        });
    }
});
