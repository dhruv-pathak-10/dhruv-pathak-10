// Role-based Access Control Configuration
const ROLES = {
    ADMIN: 'admin',
    TEACHER: 'teacher',
    STUDENT: 'student',
    PARENT: 'parent'
};

// Permission definitions
const PERMISSIONS = {
    // Student Management
    STUDENT_VIEW: 'student:view',
    STUDENT_CREATE: 'student:create',
    STUDENT_EDIT: 'student:edit',
    STUDENT_DELETE: 'student:delete',

    // Class Management
    CLASS_VIEW: 'class:view',
    CLASS_CREATE: 'class:create',
    CLASS_EDIT: 'class:edit',
    CLASS_DELETE: 'class:delete',

    // Grade Management
    GRADE_VIEW: 'grade:view',
    GRADE_CREATE: 'grade:create',
    GRADE_EDIT: 'grade:edit',
    GRADE_DELETE: 'grade:delete',

    // Attendance Management
    ATTENDANCE_VIEW: 'attendance:view',
    ATTENDANCE_MARK: 'attendance:mark',
    ATTENDANCE_EDIT: 'attendance:edit',

    // Event Management
    EVENT_VIEW: 'event:view',
    EVENT_CREATE: 'event:create',
    EVENT_EDIT: 'event:edit',
    EVENT_DELETE: 'event:delete',

    // Report Management
    REPORT_VIEW: 'report:view',
    REPORT_CREATE: 'report:create',
    REPORT_EXPORT: 'report:export',

    // System Management
    SYSTEM_SETTINGS: 'system:settings',
    USER_MANAGEMENT: 'user:management'
};

// Role-Permission mapping
const ROLE_PERMISSIONS = {
    [ROLES.ADMIN]: [
        // Admin has all permissions
        ...Object.values(PERMISSIONS)
    ],
    [ROLES.TEACHER]: [
        // Teacher permissions
        PERMISSIONS.STUDENT_VIEW,
        PERMISSIONS.CLASS_VIEW,
        PERMISSIONS.CLASS_EDIT,
        PERMISSIONS.GRADE_VIEW,
        PERMISSIONS.GRADE_CREATE,
        PERMISSIONS.GRADE_EDIT,
        PERMISSIONS.ATTENDANCE_VIEW,
        PERMISSIONS.ATTENDANCE_MARK,
        PERMISSIONS.ATTENDANCE_EDIT,
        PERMISSIONS.EVENT_VIEW,
        PERMISSIONS.EVENT_CREATE,
        PERMISSIONS.REPORT_VIEW,
        PERMISSIONS.REPORT_CREATE
    ],
    [ROLES.STUDENT]: [
        // Student permissions
        PERMISSIONS.STUDENT_VIEW,
        PERMISSIONS.CLASS_VIEW,
        PERMISSIONS.GRADE_VIEW,
        PERMISSIONS.ATTENDANCE_VIEW,
        PERMISSIONS.EVENT_VIEW
    ],
    [ROLES.PARENT]: [
        // Parent permissions
        PERMISSIONS.STUDENT_VIEW,
        PERMISSIONS.GRADE_VIEW,
        PERMISSIONS.ATTENDANCE_VIEW,
        PERMISSIONS.EVENT_VIEW,
        PERMISSIONS.REPORT_VIEW
    ]
};

// Permission checking function
function hasPermission(userRole, permission) {
    if (!ROLE_PERMISSIONS[userRole]) {
        return false;
    }
    return ROLE_PERMISSIONS[userRole].includes(permission);
}

// UI Element visibility control
function updateUIBasedOnRole(userRole) {
    const elements = document.querySelectorAll('[data-requires-permission]');
    elements.forEach(element => {
        const requiredPermission = element.dataset.requiresPermission;
        if (!hasPermission(userRole, requiredPermission)) {
            element.style.display = 'none';
        }
    });
}

// Export the configuration
export {
    ROLES,
    PERMISSIONS,
    ROLE_PERMISSIONS,
    hasPermission,
    updateUIBasedOnRole
};
