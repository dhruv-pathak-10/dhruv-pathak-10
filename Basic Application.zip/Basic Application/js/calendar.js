// Mock data for events
let events = [
    {
        id: 1,
        title: 'Mid-Term Examinations',
        start: '2025-02-15',
        end: '2025-02-20',
        category: 'exam',
        description: 'Mid-term examinations for all classes',
        location: 'School Campus',
        allDay: true,
        color: '#dc3545'
    },
    {
        id: 2,
        title: 'Annual Sports Day',
        start: '2025-03-01',
        category: 'activity',
        description: 'Annual sports event with various competitions',
        location: 'School Playground',
        allDay: true,
        color: '#28a745'
    }
];

// Category colors
const categoryColors = {
    academic: '#4e73df',
    holiday: '#1cc88a',
    exam: '#dc3545',
    activity: '#f6c23e'
};

let calendar;
let selectedEvent = null;

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', () => {
    initializeCalendar();
    updateUpcomingEvents();
    setupEventFilters();
});

// Initialize FullCalendar
function initializeCalendar() {
    const calendarEl = document.getElementById('calendar');
    calendar = new FullCalendar.Calendar(calendarEl, {
        initialView: 'dayGridMonth',
        headerToolbar: {
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,timeGridWeek,timeGridDay'
        },
        events: events,
        editable: true,
        selectable: true,
        selectMirror: true,
        dayMaxEvents: true,
        eventClick: function(info) {
            showEventDetails(info.event);
        },
        eventDrop: function(info) {
            updateEvent(info.event);
        },
        eventResize: function(info) {
            updateEvent(info.event);
        }
    });
    
    calendar.render();
}

// Add new event
function addEvent() {
    const title = document.getElementById('eventTitle').value;
    const category = document.getElementById('eventCategory').value;
    const start = document.getElementById('eventStart').value;
    const end = document.getElementById('eventEnd').value;
    const description = document.getElementById('eventDescription').value;
    const location = document.getElementById('eventLocation').value;
    const allDay = document.getElementById('allDay').checked;

    if (!title || !start) {
        alert('Please fill in all required fields');
        return;
    }

    const newEvent = {
        id: events.length + 1,
        title: title,
        start: start,
        end: end || start,
        category: category,
        description: description,
        location: location,
        allDay: allDay,
        color: categoryColors[category]
    };

    events.push(newEvent);
    calendar.addEvent(newEvent);
    updateUpcomingEvents();

    // Close modal and reset form
    $('#addEventModal').modal('hide');
    document.getElementById('addEventForm').reset();
}

// Show event details
function showEventDetails(event) {
    selectedEvent = event;
    
    const details = document.getElementById('eventDetails');
    details.innerHTML = `
        <h4>${event.title}</h4>
        <p><strong>Category:</strong> ${event.extendedProps.category}</p>
        <p><strong>Date:</strong> ${formatDate(event.start)} ${event.end ? ' - ' + formatDate(event.end) : ''}</p>
        ${event.extendedProps.description ? `<p><strong>Description:</strong> ${event.extendedProps.description}</p>` : ''}
        ${event.extendedProps.location ? `<p><strong>Location:</strong> ${event.extendedProps.location}</p>` : ''}
    `;
    
    $('#eventDetailsModal').modal('show');
}

// Delete event
function deleteEvent() {
    if (selectedEvent && confirm('Are you sure you want to delete this event?')) {
        const eventId = parseInt(selectedEvent.id);
        events = events.filter(e => e.id !== eventId);
        selectedEvent.remove();
        updateUpcomingEvents();
        $('#eventDetailsModal').modal('hide');
    }
}

// Update event after drag or resize
function updateEvent(event) {
    const eventId = parseInt(event.id);
    const eventIndex = events.findIndex(e => e.id === eventId);
    
    if (eventIndex !== -1) {
        events[eventIndex] = {
            ...events[eventIndex],
            start: event.start,
            end: event.end
        };
        updateUpcomingEvents();
    }
}

// Update upcoming events sidebar
function updateUpcomingEvents() {
    const container = document.getElementById('upcomingEvents');
    const today = new Date();
    
    // Filter and sort upcoming events
    const upcomingEvents = events
        .filter(event => new Date(event.start) >= today)
        .sort((a, b) => new Date(a.start) - new Date(b.start))
        .slice(0, 5);
    
    if (upcomingEvents.length === 0) {
        container.innerHTML = '<p class="text-muted">No upcoming events</p>';
        return;
    }
    
    container.innerHTML = '';
    upcomingEvents.forEach(event => {
        const eventElement = document.createElement('div');
        eventElement.className = 'calendar-event mb-3';
        eventElement.style.borderLeft = `4px solid ${event.color}`;
        eventElement.innerHTML = `
            <div class="fw-bold">${event.title}</div>
            <div class="small text-muted">
                ${formatDate(new Date(event.start))}
                ${event.end ? ' - ' + formatDate(new Date(event.end)) : ''}
            </div>
        `;
        container.appendChild(eventElement);
    });
}

// Setup event category filters
function setupEventFilters() {
    const filterIds = ['academicEvents', 'holidays', 'examinations', 'activities'];
    const categoryMap = {
        academicEvents: 'academic',
        holidays: 'holiday',
        examinations: 'exam',
        activities: 'activity'
    };
    
    filterIds.forEach(filterId => {
        document.getElementById(filterId).addEventListener('change', function() {
            const category = categoryMap[filterId];
            const isChecked = this.checked;
            
            calendar.getEvents().forEach(event => {
                if (event.extendedProps.category === category) {
                    event.setProp('display', isChecked ? 'auto' : 'none');
                }
            });
        });
    });
}

// Format date for display
function formatDate(date) {
    return new Date(date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}
