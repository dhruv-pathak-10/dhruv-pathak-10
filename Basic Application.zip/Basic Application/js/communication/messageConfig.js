// Message System Configuration

// Message Types
export const MESSAGE_TYPES = {
    DIRECT: 'direct',
    GROUP: 'group',
    ANNOUNCEMENT: 'announcement',
    NOTIFICATION: 'notification'
};

// Message Priority
export const MESSAGE_PRIORITY = {
    LOW: 'low',
    MEDIUM: 'medium',
    HIGH: 'high',
    URGENT: 'urgent'
};

// Message Status
export const MESSAGE_STATUS = {
    SENT: 'sent',
    DELIVERED: 'delivered',
    READ: 'read',
    FAILED: 'failed'
};

// Notification Types
export const NOTIFICATION_TYPES = {
    ACADEMIC: 'academic',
    ATTENDANCE: 'attendance',
    EXAM: 'exam',
    EVENT: 'event',
    LIBRARY: 'library',
    FEES: 'fees',
    GENERAL: 'general'
};

// Chat Room Types
export const CHAT_ROOM_TYPES = {
    CLASS: 'class',
    DEPARTMENT: 'department',
    STAFF: 'staff',
    PARENT_TEACHER: 'parent_teacher'
};

// Email Templates
export const EMAIL_TEMPLATES = {
    WELCOME: {
        subject: 'Welcome to School Management System',
        template: 'welcome_template'
    },
    PASSWORD_RESET: {
        subject: 'Password Reset Request',
        template: 'password_reset_template'
    },
    ANNOUNCEMENT: {
        subject: 'New School Announcement',
        template: 'announcement_template'
    },
    GRADE_UPDATE: {
        subject: 'Grade Update Notification',
        template: 'grade_update_template'
    },
    ATTENDANCE_ALERT: {
        subject: 'Attendance Alert',
        template: 'attendance_alert_template'
    },
    EVENT_INVITATION: {
        subject: 'School Event Invitation',
        template: 'event_invitation_template'
    },
    FEE_REMINDER: {
        subject: 'Fee Payment Reminder',
        template: 'fee_reminder_template'
    }
};

// Message Utilities
export class MessageUtilities {
    static formatMessage(message) {
        return {
            ...message,
            timestamp: new Date().toISOString(),
            status: MESSAGE_STATUS.SENT
        };
    }

    static validateMessage(message) {
        const required = ['sender', 'receiver', 'content', 'type'];
        return required.every(field => message[field]);
    }

    static generateMessageId() {
        const prefix = 'MSG';
        const timestamp = Date.now();
        const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        return `${prefix}-${timestamp}-${random}`;
    }

    static generateChatRoomId(type, identifier) {
        const prefix = 'CHAT';
        const timestamp = Date.now();
        return `${prefix}-${type}-${identifier}-${timestamp}`;
    }
}

// Notification Manager
export class NotificationManager {
    static createNotification(type, title, message, priority = MESSAGE_PRIORITY.MEDIUM) {
        return {
            id: `NOTIF-${Date.now()}`,
            type,
            title,
            message,
            priority,
            timestamp: new Date().toISOString(),
            status: MESSAGE_STATUS.SENT
        };
    }

    static formatNotificationForDisplay(notification) {
        return {
            ...notification,
            timeAgo: this.getTimeAgo(notification.timestamp),
            icon: this.getNotificationIcon(notification.type),
            priorityClass: this.getPriorityClass(notification.priority)
        };
    }

    static getTimeAgo(timestamp) {
        const seconds = Math.floor((new Date() - new Date(timestamp)) / 1000);
        
        const intervals = {
            year: 31536000,
            month: 2592000,
            week: 604800,
            day: 86400,
            hour: 3600,
            minute: 60
        };

        for (const [unit, secondsInUnit] of Object.entries(intervals)) {
            const interval = Math.floor(seconds / secondsInUnit);
            if (interval >= 1) {
                return `${interval} ${unit}${interval === 1 ? '' : 's'} ago`;
            }
        }
        
        return 'Just now';
    }

    static getNotificationIcon(type) {
        switch (type) {
            case NOTIFICATION_TYPES.ACADEMIC:
                return 'fas fa-graduation-cap';
            case NOTIFICATION_TYPES.ATTENDANCE:
                return 'fas fa-clipboard-check';
            case NOTIFICATION_TYPES.EXAM:
                return 'fas fa-file-alt';
            case NOTIFICATION_TYPES.EVENT:
                return 'fas fa-calendar-alt';
            case NOTIFICATION_TYPES.LIBRARY:
                return 'fas fa-book';
            case NOTIFICATION_TYPES.FEES:
                return 'fas fa-money-bill';
            default:
                return 'fas fa-bell';
        }
    }

    static getPriorityClass(priority) {
        switch (priority) {
            case MESSAGE_PRIORITY.LOW:
                return 'text-info';
            case MESSAGE_PRIORITY.MEDIUM:
                return 'text-primary';
            case MESSAGE_PRIORITY.HIGH:
                return 'text-warning';
            case MESSAGE_PRIORITY.URGENT:
                return 'text-danger';
            default:
                return 'text-secondary';
        }
    }
}

// Email Manager
export class EmailManager {
    static async sendEmail(template, data, recipient) {
        try {
            const emailContent = await this.generateEmailContent(template, data);
            
            // In a real application, this would use an email service
            console.log('Sending email:', {
                to: recipient,
                subject: EMAIL_TEMPLATES[template].subject,
                content: emailContent
            });

            return {
                success: true,
                messageId: `EMAIL-${Date.now()}`
            };
        } catch (error) {
            console.error('Error sending email:', error);
            throw new Error('Failed to send email');
        }
    }

    static async generateEmailContent(template, data) {
        // In a real application, this would use an HTML template engine
        const templates = {
            welcome_template: `
                <h1>Welcome to School Management System</h1>
                <p>Dear ${data.name},</p>
                <p>Welcome to our school management system. Your account has been created successfully.</p>
            `,
            password_reset_template: `
                <h1>Password Reset Request</h1>
                <p>Click the link below to reset your password:</p>
                <p><a href="${data.resetLink}">Reset Password</a></p>
            `,
            // Add more templates as needed
        };

        return templates[EMAIL_TEMPLATES[template].template] || '';
    }
}

// Chat Room Manager
export class ChatRoomManager {
    static createChatRoom(type, name, participants) {
        return {
            id: MessageUtilities.generateChatRoomId(type, name),
            type,
            name,
            participants,
            createdAt: new Date().toISOString(),
            messages: []
        };
    }

    static addMessage(chatRoom, message) {
        const formattedMessage = MessageUtilities.formatMessage(message);
        chatRoom.messages.push(formattedMessage);
        return chatRoom;
    }

    static addParticipant(chatRoom, participant) {
        if (!chatRoom.participants.includes(participant)) {
            chatRoom.participants.push(participant);
        }
        return chatRoom;
    }

    static removeParticipant(chatRoom, participant) {
        chatRoom.participants = chatRoom.participants.filter(p => p !== participant);
        return chatRoom;
    }
}
