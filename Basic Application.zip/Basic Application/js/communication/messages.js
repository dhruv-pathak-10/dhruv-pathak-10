import {
    MESSAGE_TYPES,
    MESSAGE_PRIORITY,
    MESSAGE_STATUS,
    NOTIFICATION_TYPES,
    CHAT_ROOM_TYPES,
    MessageUtilities,
    NotificationManager,
    EmailManager,
    ChatRoomManager
} from './messageConfig.js';

class MessagingSystem {
    constructor() {
        this.currentUser = null;
        this.currentChatRoom = null;
        this.chatRooms = [];
        this.messages = [];
        this.notifications = [];
        this.socket = null;

        this.initializeSocket();
        this.initializeEventListeners();
        this.loadInitialData();
    }

    initializeSocket() {
        // In a real application, this would connect to your server
        // this.socket = io('your-server-url');
        console.log('Socket initialization would happen here');
    }

    initializeEventListeners() {
        // Message form submission
        document.getElementById('messageForm').addEventListener('submit', (e) => {
            e.preventDefault();
            const input = e.target.querySelector('input');
            const message = input.value.trim();
            if (message && this.currentChatRoom) {
                this.sendMessage(message);
                input.value = '';
            }
        });

        // Search input
        const searchInput = document.querySelector('.chat-list input');
        searchInput.addEventListener('input', (e) => {
            this.searchChats(e.target.value);
        });

        // New message form
        document.getElementById('newMessageForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.sendNewMessage();
        });

        // Announcement form
        document.getElementById('announcementForm').addEventListener('submit', (e) => {
            e.preventDefault();
            this.sendAnnouncement();
        });
    }

    async loadInitialData() {
        try {
            // In a real application, this would load from your server
            this.currentUser = {
                id: 'USER123',
                name: 'John Doe',
                role: 'teacher'
            };

            // Load mock data
            await this.loadMockData();
            
            // Render initial state
            this.renderChatList();
            this.renderNotifications();
            this.updateUnreadCount();
        } catch (error) {
            console.error('Error loading initial data:', error);
            alert('Error loading messages. Please try again.');
        }
    }

    async loadMockData() {
        // Mock chat rooms
        this.chatRooms = [
            ChatRoomManager.createChatRoom(
                CHAT_ROOM_TYPES.CLASS,
                'Class 10-A Discussion',
                ['USER123', 'USER456', 'USER789']
            ),
            ChatRoomManager.createChatRoom(
                CHAT_ROOM_TYPES.DEPARTMENT,
                'Science Department',
                ['USER123', 'USER444', 'USER555']
            )
        ];

        // Mock messages
        const mockMessages = [
            {
                sender: 'USER456',
                content: 'When is the next assignment due?',
                timestamp: new Date(Date.now() - 3600000).toISOString()
            },
            {
                sender: 'USER123',
                content: 'The assignment is due next Friday.',
                timestamp: new Date(Date.now() - 3500000).toISOString()
            }
        ];

        this.chatRooms[0].messages = mockMessages.map(msg => MessageUtilities.formatMessage(msg));

        // Mock notifications
        this.notifications = [
            NotificationManager.createNotification(
                NOTIFICATION_TYPES.ACADEMIC,
                'New Assignment Posted',
                'Mathematics Assignment 3 has been posted.',
                MESSAGE_PRIORITY.MEDIUM
            ),
            NotificationManager.createNotification(
                NOTIFICATION_TYPES.EVENT,
                'Parent-Teacher Meeting',
                'Upcoming PTA meeting this Saturday.',
                MESSAGE_PRIORITY.HIGH
            )
        ];
    }

    renderChatList() {
        const container = document.getElementById('chatList');
        container.innerHTML = '';

        this.chatRooms.forEach(room => {
            const lastMessage = room.messages[room.messages.length - 1];
            const div = document.createElement('div');
            div.className = 'chat-item';
            if (this.currentChatRoom && this.currentChatRoom.id === room.id) {
                div.classList.add('active');
            }

            div.innerHTML = `
                <div class="d-flex justify-content-between">
                    <h6 class="mb-1">${room.name}</h6>
                    ${lastMessage ? `<small>${NotificationManager.getTimeAgo(lastMessage.timestamp)}</small>` : ''}
                </div>
                <p class="mb-1 text-muted small">
                    ${lastMessage ? lastMessage.content : 'No messages yet'}
                </p>
            `;

            div.addEventListener('click', () => this.selectChatRoom(room));
            container.appendChild(div);
        });
    }

    renderMessages() {
        const container = document.getElementById('messageList');
        container.innerHTML = '';

        if (!this.currentChatRoom) {
            container.innerHTML = `
                <div class="text-center text-muted p-5">
                    <i class="fas fa-comments fa-3x mb-3"></i>
                    <p>Select a chat to start messaging</p>
                </div>
            `;
            return;
        }

        this.currentChatRoom.messages.forEach(message => {
            const isSent = message.sender === this.currentUser.id;
            const div = document.createElement('div');
            div.className = `message ${isSent ? 'sent' : 'received'}`;

            div.innerHTML = `
                <div class="message-content">${message.content}</div>
                <div class="message-time">${NotificationManager.getTimeAgo(message.timestamp)}</div>
            `;

            container.appendChild(div);
        });

        // Scroll to bottom
        container.scrollTop = container.scrollHeight;
    }

    renderNotifications() {
        const container = document.querySelector('.notification-list');
        container.innerHTML = '';

        this.notifications.forEach(notification => {
            const formatted = NotificationManager.formatNotificationForDisplay(notification);
            const div = document.createElement('div');
            div.className = 'dropdown-item p-2 border-bottom';

            div.innerHTML = `
                <div class="d-flex align-items-center">
                    <i class="${formatted.icon} ${formatted.priorityClass} me-2"></i>
                    <div>
                        <h6 class="mb-0">${notification.title}</h6>
                        <p class="mb-0 small text-muted">${notification.message}</p>
                        <small class="text-muted">${formatted.timeAgo}</small>
                    </div>
                </div>
            `;

            container.appendChild(div);
        });
    }

    updateUnreadCount() {
        const unreadCount = this.notifications.filter(n => n.status !== MESSAGE_STATUS.READ).length;
        const badge = document.querySelector('.notification-badge');
        
        if (unreadCount > 0) {
            badge.textContent = unreadCount;
            badge.style.display = 'block';
        } else {
            badge.style.display = 'none';
        }
    }

    selectChatRoom(room) {
        this.currentChatRoom = room;
        
        // Update UI
        document.getElementById('chatRoomName').textContent = room.name;
        this.renderChatList();
        this.renderMessages();
        
        // Update participant list
        const participantList = document.getElementById('participantList');
        participantList.textContent = `${room.participants.length} participants`;
    }

    async sendMessage(content) {
        if (!this.currentChatRoom) return;

        const message = {
            sender: this.currentUser.id,
            content,
            type: MESSAGE_TYPES.DIRECT
        };

        if (MessageUtilities.validateMessage(message)) {
            const formattedMessage = MessageUtilities.formatMessage(message);
            this.currentChatRoom.messages.push(formattedMessage);

            // In a real application, this would be sent to the server
            // await this.socket.emit('message', formattedMessage);

            this.renderMessages();
        }
    }

    async sendNewMessage() {
        const recipient = document.getElementById('messageRecipient').value;
        const content = document.getElementById('messageContent').value;

        if (!recipient || !content) {
            alert('Please fill all fields');
            return;
        }

        try {
            const message = {
                sender: this.currentUser.id,
                receiver: recipient,
                content,
                type: MESSAGE_TYPES.DIRECT
            };

            if (MessageUtilities.validateMessage(message)) {
                // In a real application, this would be sent to the server
                console.log('Sending new message:', message);

                // Close modal and reset form
                bootstrap.Modal.getInstance(document.getElementById('newMessageModal')).hide();
                document.getElementById('newMessageForm').reset();

                alert('Message sent successfully!');
            }
        } catch (error) {
            console.error('Error sending message:', error);
            alert('Error sending message. Please try again.');
        }
    }

    async sendAnnouncement() {
        const title = document.getElementById('announcementTitle').value;
        const audience = document.getElementById('announcementAudience').value;
        const priority = document.getElementById('announcementPriority').value;
        const content = document.getElementById('announcementContent').value;
        const sendEmail = document.getElementById('sendEmail').checked;

        if (!title || !content) {
            alert('Please fill all required fields');
            return;
        }

        try {
            const announcement = {
                sender: this.currentUser.id,
                title,
                content,
                audience,
                priority,
                type: MESSAGE_TYPES.ANNOUNCEMENT
            };

            // In a real application, this would be sent to the server
            console.log('Sending announcement:', announcement);

            if (sendEmail) {
                await EmailManager.sendEmail('ANNOUNCEMENT', {
                    title,
                    content,
                    sender: this.currentUser.name
                }, 'all@school.com');
            }

            // Close modal and reset form
            bootstrap.Modal.getInstance(document.getElementById('newAnnouncementModal')).hide();
            document.getElementById('announcementForm').reset();

            alert('Announcement sent successfully!');
        } catch (error) {
            console.error('Error sending announcement:', error);
            alert('Error sending announcement. Please try again.');
        }
    }

    searchChats(query) {
        const normalizedQuery = query.toLowerCase();
        const filteredRooms = this.chatRooms.filter(room => 
            room.name.toLowerCase().includes(normalizedQuery) ||
            room.messages.some(msg => msg.content.toLowerCase().includes(normalizedQuery))
        );
        
        this.renderChatList(filteredRooms);
    }

    addParticipants() {
        // Show add participants modal
        new bootstrap.Modal(document.getElementById('addParticipantsModal')).show();
    }

    viewParticipants() {
        if (!this.currentChatRoom) return;
        
        // In a real application, this would show detailed participant information
        alert(`Participants: ${this.currentChatRoom.participants.join(', ')}`);
    }

    leaveChat() {
        if (!this.currentChatRoom) return;

        if (confirm('Are you sure you want to leave this chat?')) {
            this.chatRooms = this.chatRooms.filter(room => room.id !== this.currentChatRoom.id);
            this.currentChatRoom = null;
            this.renderChatList();
            this.renderMessages();
        }
    }
}

// Initialize messaging system and export for global access
const messagingSystem = new MessagingSystem();

// Export functions for global access
window.messagingSystem = messagingSystem;
