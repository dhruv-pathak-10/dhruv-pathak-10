import { 
    BOOK_CATEGORIES, 
    BOOK_STATUS, 
    BookManager, 
    LibrarySearch, 
    ReservationManager,
    LibraryReportGenerator 
} from './libraryConfig.js';

class LibraryManager {
    constructor() {
        this.books = [];
        this.loans = [];
        this.initializeEventListeners();
        this.loadData();
    }

    initializeEventListeners() {
        // Search input handler
        document.getElementById('searchInput').addEventListener('input', (e) => {
            this.handleSearch(e.target.value);
        });

        // Filter change handlers
        document.getElementById('categoryFilter').addEventListener('change', () => this.applyFilters());
        document.getElementById('statusFilter').addEventListener('change', () => this.applyFilters());
        document.getElementById('sortBy').addEventListener('change', () => this.applyFilters());
        document.getElementById('sortOrder').addEventListener('change', () => this.applyFilters());

        // Initialize filter dropdowns
        this.initializeFilterDropdowns();
    }

    initializeFilterDropdowns() {
        // Populate category filter
        const categorySelect = document.getElementById('categoryFilter');
        Object.values(BOOK_CATEGORIES).forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            categorySelect.appendChild(option);
        });

        // Populate status filter
        const statusSelect = document.getElementById('statusFilter');
        Object.values(BOOK_STATUS).forEach(status => {
            const option = document.createElement('option');
            option.value = status;
            option.textContent = status.replace('_', ' ').toUpperCase();
            statusSelect.appendChild(option);
        });

        // Populate book category dropdown in add form
        const bookCategorySelect = document.getElementById('bookCategory');
        Object.values(BOOK_CATEGORIES).forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            bookCategorySelect.appendChild(option);
        });
    }

    async loadData() {
        try {
            // In a real application, this would load from a server
            // For now, we'll use mock data
            this.books = [
                {
                    id: 'BK-001',
                    isbn: '9780123456789',
                    title: 'Introduction to Mathematics',
                    author: 'John Smith',
                    category: BOOK_CATEGORIES.TEXTBOOK,
                    publisher: 'Education Press',
                    publishYear: 2020,
                    status: BOOK_STATUS.AVAILABLE,
                    quantity: 5,
                    available: 5,
                    description: 'A comprehensive introduction to mathematics for high school students.',
                    reservations: []
                },
                // Add more mock books as needed
            ];
            
            this.renderBooks();
            this.updateStats();
        } catch (error) {
            console.error('Error loading library data:', error);
            alert('Error loading library data. Please try again.');
        }
    }

    handleSearch(query) {
        const searchResults = LibrarySearch.searchBooks(this.books, query);
        this.renderBooks(searchResults);
    }

    applyFilters() {
        const category = document.getElementById('categoryFilter').value;
        const status = document.getElementById('statusFilter').value;
        const sortBy = document.getElementById('sortBy').value;
        const ascending = document.getElementById('sortOrder').value === 'asc';

        let filteredBooks = LibrarySearch.searchBooks(this.books, '', {
            category: category,
            status: status
        });

        filteredBooks = LibrarySearch.sortBooks(filteredBooks, sortBy, ascending);
        this.renderBooks(filteredBooks);
    }

    renderBooks(books = this.books) {
        const container = document.getElementById('booksGrid');
        container.innerHTML = '';

        books.forEach(book => {
            const card = this.createBookCard(book);
            container.appendChild(card);
        });
    }

    createBookCard(book) {
        const col = document.createElement('div');
        col.className = 'col-md-4 mb-4';
        
        col.innerHTML = `
            <div class="card book-card h-100">
                <div class="card-body">
                    <span class="status-badge badge bg-${this.getStatusBadgeColor(book.status)}">
                        ${book.status.replace('_', ' ').toUpperCase()}
                    </span>
                    <h5 class="card-title">${book.title}</h5>
                    <h6 class="card-subtitle mb-2 text-muted">by ${book.author}</h6>
                    <p class="card-text">
                        <small>
                            <strong>ISBN:</strong> ${book.isbn}<br>
                            <strong>Category:</strong> ${book.category}<br>
                            <strong>Available:</strong> ${book.available}/${book.quantity}
                        </small>
                    </p>
                    <button class="btn btn-primary btn-sm" onclick="libraryManager.showBookDetails('${book.id}')">
                        View Details
                    </button>
                </div>
            </div>
        `;

        return col;
    }

    getStatusBadgeColor(status) {
        switch (status) {
            case BOOK_STATUS.AVAILABLE:
                return 'success';
            case BOOK_STATUS.CHECKED_OUT:
                return 'warning';
            case BOOK_STATUS.RESERVED:
                return 'info';
            case BOOK_STATUS.MAINTENANCE:
                return 'secondary';
            case BOOK_STATUS.LOST:
                return 'danger';
            default:
                return 'primary';
        }
    }

    showBookDetails(bookId) {
        const book = this.books.find(b => b.id === bookId);
        if (!book) return;

        // Populate modal with book details
        document.getElementById('detailTitle').textContent = book.title;
        document.getElementById('detailAuthor').textContent = book.author;
        document.getElementById('detailISBN').textContent = book.isbn;
        document.getElementById('detailCategory').textContent = book.category;
        document.getElementById('detailPublisher').textContent = book.publisher;
        document.getElementById('detailPublishYear').textContent = book.publishYear;
        document.getElementById('detailDescription').textContent = book.description;
        document.getElementById('detailStatus').textContent = book.status.replace('_', ' ').toUpperCase();
        document.getElementById('detailAvailability').textContent = `${book.available}/${book.quantity} copies available`;

        // Update action buttons
        const actionButtons = document.getElementById('actionButtons');
        actionButtons.innerHTML = '';

        if (book.status === BOOK_STATUS.AVAILABLE) {
            actionButtons.innerHTML = `
                <button class="btn btn-primary w-100 mb-2" onclick="libraryManager.showCheckoutModal('${book.id}')">
                    Checkout
                </button>
            `;
        } else if (book.status === BOOK_STATUS.CHECKED_OUT && ReservationManager.canReserve(book, 'current_user_id')) {
            actionButtons.innerHTML = `
                <button class="btn btn-warning w-100 mb-2" onclick="libraryManager.reserveBook('${book.id}')">
                    Reserve
                </button>
            `;
        }

        // Show modal
        new bootstrap.Modal(document.getElementById('bookDetailsModal')).show();
    }

    showCheckoutModal(bookId) {
        this.currentBookId = bookId;
        new bootstrap.Modal(document.getElementById('checkoutModal')).show();
    }

    async processCheckout() {
        const borrowerId = document.getElementById('borrowerId').value;
        const dueDate = document.getElementById('dueDate').value;

        if (!borrowerId || !dueDate) {
            alert('Please fill all fields');
            return;
        }

        try {
            const book = this.books.find(b => b.id === this.currentBookId);
            if (!book || book.available === 0) {
                throw new Error('Book not available');
            }

            // Update book status
            book.available--;
            if (book.available === 0) {
                book.status = BOOK_STATUS.CHECKED_OUT;
            }

            // Create loan record
            const loan = {
                id: `LOAN-${Date.now()}`,
                bookId: book.id,
                borrowerId: borrowerId,
                checkoutDate: new Date().toISOString(),
                dueDate: dueDate,
                returnDate: null,
                status: 'active'
            };

            this.loans.push(loan);

            // Process any pending reservations
            ReservationManager.processReservations(book);

            // Update UI
            this.renderBooks();
            this.updateStats();

            // Close modal
            bootstrap.Modal.getInstance(document.getElementById('checkoutModal')).hide();
            document.getElementById('checkoutForm').reset();

            alert('Book checked out successfully!');
        } catch (error) {
            console.error('Error processing checkout:', error);
            alert('Error processing checkout. Please try again.');
        }
    }

    async reserveBook(bookId) {
        try {
            const book = this.books.find(b => b.id === bookId);
            if (!book) {
                throw new Error('Book not found');
            }

            ReservationManager.addReservation(book, 'current_user_id');
            this.renderBooks();
            
            // Close details modal
            bootstrap.Modal.getInstance(document.getElementById('bookDetailsModal')).hide();
            
            alert('Book reserved successfully! You will be notified when it becomes available.');
        } catch (error) {
            console.error('Error reserving book:', error);
            alert('Error reserving book. Please try again.');
        }
    }

    async saveBook() {
        const formData = {
            isbn: document.getElementById('bookISBN').value,
            title: document.getElementById('bookTitle').value,
            author: document.getElementById('bookAuthor').value,
            category: document.getElementById('bookCategory').value,
            publisher: document.getElementById('bookPublisher').value,
            publishYear: document.getElementById('bookPublishYear').value,
            quantity: parseInt(document.getElementById('bookQuantity').value),
            description: document.getElementById('bookDescription').value
        };

        // Validate ISBN
        if (!BookManager.validateISBN(formData.isbn)) {
            alert('Invalid ISBN format');
            return;
        }

        try {
            const newBook = {
                id: BookManager.generateBookId(),
                ...formData,
                status: BOOK_STATUS.AVAILABLE,
                available: formData.quantity,
                reservations: []
            };

            this.books.push(newBook);
            this.renderBooks();
            this.updateStats();

            // Close modal and reset form
            bootstrap.Modal.getInstance(document.getElementById('addBookModal')).hide();
            document.getElementById('addBookForm').reset();

            alert('Book added successfully!');
        } catch (error) {
            console.error('Error saving book:', error);
            alert('Error saving book. Please try again.');
        }
    }

    updateStats() {
        const stats = LibraryReportGenerator.generateBookReport(this.books);
        
        document.getElementById('totalBooks').textContent = stats.totalBooks;
        document.getElementById('availableBooks').textContent = stats.availableBooks;
        document.getElementById('checkedOutBooks').textContent = stats.checkedOutBooks;
        document.getElementById('reservedBooks').textContent = 
            this.books.reduce((count, book) => count + book.reservations.length, 0);
    }
}

// Initialize library manager and export for global access
const libraryManager = new LibraryManager();

// Export functions for global access
window.libraryManager = libraryManager;
