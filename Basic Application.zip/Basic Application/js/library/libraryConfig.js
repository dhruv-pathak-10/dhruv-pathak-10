// Library Management Configuration

// Book Categories
export const BOOK_CATEGORIES = {
    FICTION: 'Fiction',
    NON_FICTION: 'Non-Fiction',
    REFERENCE: 'Reference',
    TEXTBOOK: 'Textbook',
    MAGAZINE: 'Magazine',
    JOURNAL: 'Journal'
};

// Book Status
export const BOOK_STATUS = {
    AVAILABLE: 'available',
    CHECKED_OUT: 'checked_out',
    RESERVED: 'reserved',
    MAINTENANCE: 'maintenance',
    LOST: 'lost'
};

// Loan Duration (in days)
export const LOAN_DURATION = {
    STUDENT: 14,
    TEACHER: 30,
    REFERENCE: 0  // Reference books cannot be checked out
};

// Maximum Books Allowed
export const MAX_BOOKS = {
    STUDENT: 3,
    TEACHER: 5
};

// Fine Rates (per day)
export const FINE_RATE = 2.00;  // $2 per day

// Book Manager Class
export class BookManager {
    static validateISBN(isbn) {
        // Remove hyphens and spaces
        isbn = isbn.replace(/[-\s]/g, '');

        // Check if it's ISBN-13
        if (isbn.length === 13) {
            return this.validateISBN13(isbn);
        }
        // Check if it's ISBN-10
        else if (isbn.length === 10) {
            return this.validateISBN10(isbn);
        }

        return false;
    }

    static validateISBN10(isbn) {
        let sum = 0;
        for (let i = 0; i < 9; i++) {
            sum += (10 - i) * parseInt(isbn[i]);
        }
        
        // Check digit can be 'X' (representing 10)
        const lastChar = isbn[9].toUpperCase();
        const checkDigit = (lastChar === 'X') ? 10 : parseInt(lastChar);
        
        sum += checkDigit;
        return sum % 11 === 0;
    }

    static validateISBN13(isbn) {
        let sum = 0;
        for (let i = 0; i < 12; i++) {
            sum += (i % 2 === 0 ? 1 : 3) * parseInt(isbn[i]);
        }
        
        const checkDigit = (10 - (sum % 10)) % 10;
        return checkDigit === parseInt(isbn[12]);
    }

    static generateDueDate(userType) {
        const dueDate = new Date();
        dueDate.setDate(dueDate.getDate() + LOAN_DURATION[userType]);
        return dueDate;
    }

    static calculateFine(dueDate) {
        const today = new Date();
        const due = new Date(dueDate);
        
        if (today <= due) {
            return 0;
        }

        const daysLate = Math.floor((today - due) / (1000 * 60 * 60 * 24));
        return daysLate * FINE_RATE;
    }

    static canBorrow(userType, currentlyBorrowed) {
        return currentlyBorrowed < MAX_BOOKS[userType];
    }

    static generateBookId() {
        const prefix = 'BK';
        const timestamp = Date.now();
        const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        return `${prefix}-${timestamp}-${random}`;
    }
}

// Search and Filter Utilities
export class LibrarySearch {
    static searchBooks(books, query, filters = {}) {
        return books.filter(book => {
            // Basic search
            const searchMatch = this.matchesSearchQuery(book, query);
            
            // Apply filters
            const filterMatch = this.matchesFilters(book, filters);
            
            return searchMatch && filterMatch;
        });
    }

    static matchesSearchQuery(book, query) {
        if (!query) return true;
        
        const searchFields = [
            book.title,
            book.author,
            book.isbn,
            book.publisher,
            book.description
        ];

        query = query.toLowerCase();
        return searchFields.some(field => 
            field && field.toLowerCase().includes(query)
        );
    }

    static matchesFilters(book, filters) {
        for (const [key, value] of Object.entries(filters)) {
            if (!value) continue;

            switch (key) {
                case 'category':
                    if (book.category !== value) return false;
                    break;
                case 'status':
                    if (book.status !== value) return false;
                    break;
                case 'publishYear':
                    if (book.publishYear !== value) return false;
                    break;
                case 'available':
                    if (value && book.status !== BOOK_STATUS.AVAILABLE) return false;
                    break;
            }
        }
        return true;
    }

    static sortBooks(books, sortBy = 'title', ascending = true) {
        return [...books].sort((a, b) => {
            let comparison = 0;
            
            switch (sortBy) {
                case 'title':
                    comparison = a.title.localeCompare(b.title);
                    break;
                case 'author':
                    comparison = a.author.localeCompare(b.author);
                    break;
                case 'publishYear':
                    comparison = a.publishYear - b.publishYear;
                    break;
                case 'status':
                    comparison = a.status.localeCompare(b.status);
                    break;
            }
            
            return ascending ? comparison : -comparison;
        });
    }
}

// Reservation System
export class ReservationManager {
    static canReserve(book, userId) {
        return book.status === BOOK_STATUS.CHECKED_OUT && 
               !book.reservations.some(r => r.userId === userId);
    }

    static addReservation(book, userId) {
        if (!this.canReserve(book, userId)) {
            throw new Error('Book cannot be reserved');
        }

        book.reservations.push({
            userId,
            date: new Date().toISOString(),
            status: 'pending'
        });

        return book;
    }

    static processReservations(book) {
        if (book.status !== BOOK_STATUS.AVAILABLE || book.reservations.length === 0) {
            return null;
        }

        // Get the earliest reservation
        const nextReservation = book.reservations
            .filter(r => r.status === 'pending')
            .sort((a, b) => new Date(a.date) - new Date(b.date))[0];

        if (nextReservation) {
            nextReservation.status = 'ready';
            // In a real application, this would trigger a notification
            return nextReservation;
        }

        return null;
    }
}

// Report Generator
export class LibraryReportGenerator {
    static generateBookReport(books) {
        const totalBooks = books.length;
        const availableBooks = books.filter(b => b.status === BOOK_STATUS.AVAILABLE).length;
        const checkedOutBooks = books.filter(b => b.status === BOOK_STATUS.CHECKED_OUT).length;
        
        const categoryDistribution = {};
        books.forEach(book => {
            categoryDistribution[book.category] = (categoryDistribution[book.category] || 0) + 1;
        });

        return {
            totalBooks,
            availableBooks,
            checkedOutBooks,
            categoryDistribution,
            utilization: (checkedOutBooks / totalBooks) * 100
        };
    }

    static generateUserReport(loans) {
        return loans.reduce((report, loan) => {
            const userType = loan.userType;
            report[userType] = report[userType] || {
                totalLoans: 0,
                activeLoans: 0,
                overdue: 0,
                fines: 0
            };

            report[userType].totalLoans++;
            
            if (loan.returnDate === null) {
                report[userType].activeLoans++;
                
                const fine = BookManager.calculateFine(loan.dueDate);
                if (fine > 0) {
                    report[userType].overdue++;
                    report[userType].fines += fine;
                }
            }

            return report;
        }, {});
    }
}
