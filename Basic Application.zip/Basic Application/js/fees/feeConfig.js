// Fee Management Configuration

// Fee Types
export const FEE_TYPES = {
    TUITION: 'tuition',
    EXAM: 'exam',
    LABORATORY: 'laboratory',
    LIBRARY: 'library',
    SPORTS: 'sports',
    TRANSPORT: 'transport',
    EVENTS: 'events'
};

// Fee Structure
export const FEE_STRUCTURE = {
    'Class 10': {
        [FEE_TYPES.TUITION]: 5000,
        [FEE_TYPES.EXAM]: 500,
        [FEE_TYPES.LABORATORY]: 800,
        [FEE_TYPES.LIBRARY]: 300,
        [FEE_TYPES.SPORTS]: 400,
        [FEE_TYPES.TRANSPORT]: 1200
    },
    'Class 11': {
        [FEE_TYPES.TUITION]: 6000,
        [FEE_TYPES.EXAM]: 600,
        [FEE_TYPES.LABORATORY]: 1000,
        [FEE_TYPES.LIBRARY]: 300,
        [FEE_TYPES.SPORTS]: 400,
        [FEE_TYPES.TRANSPORT]: 1200
    },
    'Class 12': {
        [FEE_TYPES.TUITION]: 7000,
        [FEE_TYPES.EXAM]: 700,
        [FEE_TYPES.LABORATORY]: 1200,
        [FEE_TYPES.LIBRARY]: 300,
        [FEE_TYPES.SPORTS]: 400,
        [FEE_TYPES.TRANSPORT]: 1200
    }
};

// Payment Methods
export const PAYMENT_METHODS = {
    CASH: 'cash',
    CARD: 'card',
    BANK_TRANSFER: 'bank_transfer',
    ONLINE: 'online'
};

// Payment Status
export const PAYMENT_STATUS = {
    PENDING: 'pending',
    PARTIAL: 'partial',
    PAID: 'paid',
    OVERDUE: 'overdue'
};

// Discount Types
export const DISCOUNT_TYPES = {
    MERIT: {
        name: 'Merit Scholarship',
        percentage: 50
    },
    SIBLING: {
        name: 'Sibling Discount',
        percentage: 10
    },
    EARLY_BIRD: {
        name: 'Early Bird Discount',
        percentage: 5
    },
    STAFF: {
        name: 'Staff Ward Discount',
        percentage: 25
    }
};

// Fee Calculator
export class FeeCalculator {
    static calculateTotalFees(className, selectedFees = [], transport = false) {
        if (!FEE_STRUCTURE[className]) {
            throw new Error('Invalid class name');
        }

        let total = 0;
        selectedFees.forEach(feeType => {
            if (FEE_STRUCTURE[className][feeType]) {
                total += FEE_STRUCTURE[className][feeType];
            }
        });

        if (transport && FEE_STRUCTURE[className][FEE_TYPES.TRANSPORT]) {
            total += FEE_STRUCTURE[className][FEE_TYPES.TRANSPORT];
        }

        return total;
    }

    static calculateDiscount(amount, discountType) {
        if (!DISCOUNT_TYPES[discountType]) {
            return 0;
        }

        return (amount * DISCOUNT_TYPES[discountType].percentage) / 100;
    }

    static calculateLateFee(dueDate, amount) {
        const today = new Date();
        const due = new Date(dueDate);
        
        if (today <= due) {
            return 0;
        }

        const daysLate = Math.floor((today - due) / (1000 * 60 * 60 * 24));
        // 1% per week late, capped at 10%
        const lateFeePercentage = Math.min(Math.floor(daysLate / 7) * 1, 10);
        return (amount * lateFeePercentage) / 100;
    }

    static generatePaymentSchedule(totalAmount, installments = 1) {
        const schedule = [];
        const installmentAmount = Math.ceil(totalAmount / installments);
        const today = new Date();

        for (let i = 0; i < installments; i++) {
            const dueDate = new Date(today);
            dueDate.setMonth(today.getMonth() + i);
            
            schedule.push({
                installmentNumber: i + 1,
                amount: i === installments - 1 ? 
                    totalAmount - (installmentAmount * (installments - 1)) : 
                    installmentAmount,
                dueDate: dueDate.toISOString().split('T')[0]
            });
        }

        return schedule;
    }
}

// Invoice Generator
export class InvoiceGenerator {
    static generateInvoiceNumber() {
        const prefix = 'INV';
        const timestamp = Date.now();
        const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
        return `${prefix}-${timestamp}-${random}`;
    }

    static generateInvoice(studentData, feeDetails, paymentSchedule) {
        return {
            invoiceNumber: this.generateInvoiceNumber(),
            dateGenerated: new Date().toISOString(),
            studentDetails: {
                id: studentData.id,
                name: studentData.name,
                class: studentData.class,
                section: studentData.section
            },
            feeBreakdown: feeDetails.map(fee => ({
                type: fee.type,
                amount: FEE_STRUCTURE[studentData.class][fee.type] || 0
            })),
            subtotal: feeDetails.reduce((total, fee) => 
                total + (FEE_STRUCTURE[studentData.class][fee.type] || 0), 0),
            discount: {
                type: feeDetails.discountType,
                amount: feeDetails.discountAmount || 0
            },
            total: feeDetails.totalAmount,
            paymentSchedule: paymentSchedule,
            terms: [
                'Payment is due by the specified due date',
                'Late payments will incur a fee of 1% per week, up to 10%',
                'All fees are non-refundable once paid'
            ]
        };
    }
}
