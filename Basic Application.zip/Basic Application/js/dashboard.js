// Check authentication
function checkAuth() {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    if (!isLoggedIn) {
        window.location.href = 'index.html';
    }
}

// Initialize dashboard
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    initializeSidebar();
    initializeStats();
    loadActivities();
    initializeNotifications();
    initializeDarkMode();
});

// Sidebar functionality
function initializeSidebar() {
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');
    const sidebarCollapse = document.getElementById('sidebarCollapse');
    const sidebarCollapseDesktop = document.getElementById('sidebarCollapseDesktop');
    const overlay = document.createElement('div');
    
    overlay.classList.add('sidebar-overlay');
    document.body.appendChild(overlay);
    
    // Mobile toggle
    sidebarCollapse?.addEventListener('click', () => {
        sidebar.classList.toggle('active');
        overlay.classList.toggle('active');
    });
    
    // Desktop toggle
    sidebarCollapseDesktop?.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
        content.classList.toggle('expanded');
    });
    
    // Close sidebar when clicking overlay
    overlay.addEventListener('click', () => {
        sidebar.classList.remove('active');
        overlay.classList.remove('active');
    });
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', (e) => {
        if (window.innerWidth < 992 && 
            !sidebar.contains(e.target) && 
            !sidebarCollapse.contains(e.target)) {
            sidebar.classList.remove('active');
            overlay.classList.remove('active');
        }
    });
}

// Initialize statistics
function initializeStats() {
    const stats = [
        { element: 'totalStudents', value: 2450 },
        { element: 'totalTeachers', value: 120 },
        { element: 'totalClasses', value: 45 },
        { element: 'totalRevenue', value: 125000 }
    ];
    
    stats.forEach(stat => {
        const element = document.getElementById(stat.element);
        if (element) {
            animateNumber(element, 0, stat.value, 2000);
        }
    });
}

// Animate number
function animateNumber(element, start, end, duration) {
    let current = start;
    const range = end - start;
    const increment = end > start ? 1 : -1;
    const stepTime = Math.abs(Math.floor(duration / range));
    
    const timer = setInterval(() => {
        current += increment;
        element.textContent = current.toLocaleString();
        
        if (current === end) {
            clearInterval(timer);
        }
    }, stepTime);
}

// Load activities
function loadActivities() {
    const activities = [
        {
            type: 'info',
            icon: 'user',
            text: 'New student registration',
            time: '5 minutes ago'
        },
        {
            type: 'success',
            icon: 'dollar-sign',
            text: 'Fee payment received',
            time: '10 minutes ago'
        },
        {
            type: 'warning',
            icon: 'calendar',
            text: 'Parent meeting scheduled',
            time: '30 minutes ago'
        }
    ];
    
    const activityList = document.getElementById('activityList');
    if (!activityList) return;
    
    activityList.innerHTML = activities.map(activity => `
        <div class="activity-item">
            <div class="activity-icon bg-${activity.type}-light text-${activity.type}">
                <i class="fas fa-${activity.icon}"></i>
            </div>
            <div class="activity-content">
                <div class="activity-text">${activity.text}</div>
                <div class="activity-time text-muted">${activity.time}</div>
            </div>
        </div>
    `).join('');
}

// Initialize notifications
function initializeNotifications() {
    const notificationButton = document.querySelector('.notification-button');
    const notificationDropdown = document.querySelector('.notification-dropdown');
    
    if (!notificationButton || !notificationDropdown) return;
    
    notificationButton.addEventListener('click', (e) => {
        e.stopPropagation();
        notificationDropdown.classList.toggle('show');
        
        if (notificationDropdown.classList.contains('show')) {
            const badge = notificationButton.querySelector('.badge');
            if (badge) {
                badge.style.display = 'none';
            }
        }
    });
    
    document.addEventListener('click', (e) => {
        if (!notificationDropdown.contains(e.target)) {
            notificationDropdown.classList.remove('show');
        }
    });
}

// Initialize dark mode
function initializeDarkMode() {
    const darkModeToggle = document.getElementById('darkModeToggle');
    if (!darkModeToggle) return;
    
    // Check for saved dark mode preference
    if (localStorage.getItem('darkMode') === 'true') {
        document.body.classList.add('dark-mode');
        darkModeToggle.querySelector('i').className = 'fas fa-sun';
    }
    
    darkModeToggle.addEventListener('click', () => {
        document.body.classList.toggle('dark-mode');
        const icon = darkModeToggle.querySelector('i');
        
        if (document.body.classList.contains('dark-mode')) {
            icon.className = 'fas fa-sun';
            localStorage.setItem('darkMode', 'true');
        } else {
            icon.className = 'fas fa-moon';
            localStorage.setItem('darkMode', 'false');
        }
    });
}

// Utility function to format dates
function formatDate(date) {
    return new Intl.DateTimeFormat('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    }).format(date);
}

// Utility function to format time
function formatTime(date) {
    return new Intl.DateTimeFormat('en-US', {
        hour: '2-digit',
        minute: '2-digit'
    }).format(date);
}

// Handle logout
function handleLogout() {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userEmail');
    window.location.href = 'index.html';
}

// Add event listener for logout button
document.getElementById('logoutButton')?.addEventListener('click', handleLogout);
