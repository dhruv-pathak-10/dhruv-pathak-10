// Sample data for fees
let feesData = [
    {
        id: 1,
        studentId: "STU001",
        name: "John Doe",
        class: "10",
        feeType: "Tuition Fee",
        amount: 15000,
        dueDate: "2025-02-15",
        status: "paid"
    },
    {
        id: 2,
        studentId: "STU002",
        name: "Jane Smith",
        class: "9",
        feeType: "Library Fee",
        amount: 5000,
        dueDate: "2025-02-10",
        status: "pending"
    },
    {
        id: 3,
        studentId: "STU003",
        name: "Mike Johnson",
        class: "8",
        feeType: "Sports Fee",
        amount: 3000,
        dueDate: "2025-01-20",
        status: "overdue"
    }
];

// Initialize dashboard
document.addEventListener('DOMContentLoaded', () => {
    loadFeesData();
    updateStatistics();
    initializeFilters();
});

// Load fees data into table
function loadFeesData(filteredData = feesData) {
    const tableBody = document.querySelector('#feesTable tbody');
    if (!tableBody) return;

    tableBody.innerHTML = '';

    filteredData.forEach(fee => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${fee.studentId}</td>
            <td>${fee.name}</td>
            <td>Class ${fee.class}</td>
            <td>${fee.feeType}</td>
            <td>₹${fee.amount.toLocaleString()}</td>
            <td>${formatDate(fee.dueDate)}</td>
            <td>
                <span class="badge bg-${getStatusColor(fee.status)}">
                    ${fee.status.charAt(0).toUpperCase() + fee.status.slice(1)}
                </span>
            </td>
            <td>
                <button class="btn btn-sm btn-primary me-1" onclick="markAsPaid(${fee.id})">
                    <i class="fas fa-check"></i>
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteFee(${fee.id})">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        tableBody.appendChild(row);
    });
}

// Update statistics cards
function updateStatistics() {
    const totalFees = feesData.reduce((sum, fee) => sum + fee.amount, 0);
    const collectedFees = feesData.filter(fee => fee.status === 'paid').reduce((sum, fee) => sum + fee.amount, 0);
    const pendingFees = feesData.filter(fee => fee.status === 'pending').reduce((sum, fee) => sum + fee.amount, 0);
    const overdueFees = feesData.filter(fee => fee.status === 'overdue').reduce((sum, fee) => sum + fee.amount, 0);

    document.getElementById('totalFees').textContent = `₹${totalFees.toLocaleString()}`;
    document.getElementById('collectedFees').textContent = `₹${collectedFees.toLocaleString()}`;
    document.getElementById('pendingFees').textContent = `₹${pendingFees.toLocaleString()}`;
    document.getElementById('overdueFees').textContent = `₹${overdueFees.toLocaleString()}`;

    // Animate the numbers
    animateValue('totalFees', 0, totalFees, 1000);
    animateValue('collectedFees', 0, collectedFees, 1000);
    animateValue('pendingFees', 0, pendingFees, 1000);
    animateValue('overdueFees', 0, overdueFees, 1000);
}

// Initialize filters
function initializeFilters() {
    const classFilter = document.getElementById('classFilter');
    const statusFilter = document.getElementById('statusFilter');

    if (classFilter && statusFilter) {
        classFilter.addEventListener('change', applyFilters);
        statusFilter.addEventListener('change', applyFilters);
    }
}

// Apply filters
function applyFilters() {
    const classValue = document.getElementById('classFilter').value;
    const statusValue = document.getElementById('statusFilter').value;

    let filteredData = feesData;

    if (classValue) {
        filteredData = filteredData.filter(fee => fee.class === classValue);
    }

    if (statusValue) {
        filteredData = filteredData.filter(fee => fee.status === statusValue);
    }

    loadFeesData(filteredData);
}

// Add new fee
function addNewFee() {
    const studentId = document.getElementById('studentId').value;
    const feeType = document.getElementById('feeType').value;
    const amount = parseFloat(document.getElementById('feeAmount').value);
    const dueDate = document.getElementById('dueDate').value;

    if (!studentId || !feeType || !amount || !dueDate) {
        alert('Please fill all required fields');
        return;
    }

    const newFee = {
        id: feesData.length + 1,
        studentId: studentId,
        name: "New Student", // In a real app, this would be fetched from a database
        class: "10", // This would also be fetched
        feeType: feeType,
        amount: amount,
        dueDate: dueDate,
        status: "pending"
    };

    feesData.push(newFee);
    loadFeesData();
    updateStatistics();

    // Close modal and reset form
    const modal = bootstrap.Modal.getInstance(document.getElementById('addFeeModal'));
    modal.hide();
    document.getElementById('addFeeForm').reset();
}

// Mark fee as paid
function markAsPaid(id) {
    const fee = feesData.find(f => f.id === id);
    if (fee) {
        fee.status = 'paid';
        loadFeesData();
        updateStatistics();
    }
}

// Delete fee
function deleteFee(id) {
    if (confirm('Are you sure you want to delete this fee?')) {
        feesData = feesData.filter(f => f.id !== id);
        loadFeesData();
        updateStatistics();
    }
}

// Utility function to format date
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
}

// Utility function to get status color
function getStatusColor(status) {
    switch (status) {
        case 'paid': return 'success';
        case 'pending': return 'warning';
        case 'overdue': return 'danger';
        default: return 'secondary';
    }
}

// Utility function to animate number values
function animateValue(elementId, start, end, duration) {
    const element = document.getElementById(elementId);
    if (!element) return;

    let current = start;
    const range = end - start;
    const increment = end > start ? 1 : -1;
    const stepTime = Math.abs(Math.floor(duration / range));

    const timer = setInterval(() => {
        current += increment;
        element.textContent = `₹${current.toLocaleString()}`;
        
        if (current === end) {
            clearInterval(timer);
        }
    }, stepTime);
}

// Initialize sidebar toggle
document.addEventListener('DOMContentLoaded', () => {
    const sidebarCollapse = document.getElementById('sidebarCollapse');
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');

    if (sidebarCollapse && sidebar && content) {
        sidebarCollapse.addEventListener('click', () => {
            sidebar.classList.toggle('active');
            content.classList.toggle('active');
        });
    }
});
