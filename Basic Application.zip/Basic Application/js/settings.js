document.addEventListener('DOMContentLoaded', () => {
    initializeSettings();
    setupFormHandlers();
});

function initializeSettings() {
    // Load user preferences from localStorage or default values
    const preferences = JSON.parse(localStorage.getItem('userPreferences')) || getDefaultPreferences();
    applyPreferences(preferences);
}

function getDefaultPreferences() {
    return {
        theme: 'light',
        fontSize: 'medium',
        notifications: {
            email: {
                news: true,
                fees: true,
                events: false
            },
            push: {
                messages: true,
                updates: true
            }
        },
        security: {
            twoFactor: false
        }
    };
}

function applyPreferences(preferences) {
    // Apply theme
    document.querySelector(`#${preferences.theme}Theme`)?.checked = true;
    
    // Apply font size
    const fontSizeSelect = document.querySelector('select.form-select');
    if (fontSizeSelect) {
        fontSizeSelect.value = preferences.fontSize;
    }

    // Apply notification settings
    if (preferences.notifications) {
        const { email, push } = preferences.notifications;
        document.getElementById('emailNews').checked = email.news;
        document.getElementById('emailFees').checked = email.fees;
        document.getElementById('emailEvents').checked = email.events;
        document.getElementById('pushMessages').checked = push.messages;
        document.getElementById('pushUpdates').checked = push.updates;
    }

    // Apply security settings
    if (preferences.security) {
        document.getElementById('twoFactor').checked = preferences.security.twoFactor;
    }
}

function setupFormHandlers() {
    // Profile form
    const profileForm = document.getElementById('profileForm');
    profileForm?.addEventListener('submit', (e) => {
        e.preventDefault();
        showToast('Profile updated successfully');
    });

    // Notification form
    const notificationForm = document.getElementById('notificationForm');
    notificationForm?.addEventListener('submit', (e) => {
        e.preventDefault();
        const preferences = {
            notifications: {
                email: {
                    news: document.getElementById('emailNews').checked,
                    fees: document.getElementById('emailFees').checked,
                    events: document.getElementById('emailEvents').checked
                },
                push: {
                    messages: document.getElementById('pushMessages').checked,
                    updates: document.getElementById('pushUpdates').checked
                }
            }
        };
        localStorage.setItem('userPreferences', JSON.stringify(preferences));
        showToast('Notification preferences saved');
    });

    // Security form
    const securityForm = document.getElementById('securityForm');
    securityForm?.addEventListener('submit', (e) => {
        e.preventDefault();
        showToast('Security settings updated');
    });

    // Appearance form
    const appearanceForm = document.getElementById('appearanceForm');
    appearanceForm?.addEventListener('submit', (e) => {
        e.preventDefault();
        const theme = document.querySelector('input[name="theme"]:checked').id.replace('Theme', '');
        const fontSize = document.querySelector('select.form-select').value;
        
        const preferences = {
            theme,
            fontSize
        };
        
        localStorage.setItem('userPreferences', JSON.stringify(preferences));
        showToast('Appearance settings saved');
    });
}

function showToast(message) {
    // Create toast container if it doesn't exist
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }

    // Create toast
    const toastElement = document.createElement('div');
    toastElement.className = 'toast';
    toastElement.innerHTML = `
        <div class="toast-header">
            <strong class="me-auto">Notification</strong>
            <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
        </div>
        <div class="toast-body">
            ${message}
        </div>
    `;

    toastContainer.appendChild(toastElement);
    const toast = new bootstrap.Toast(toastElement);
    toast.show();
}
