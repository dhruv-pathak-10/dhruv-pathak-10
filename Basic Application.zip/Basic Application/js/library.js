// Library Management System JavaScript

// Check authentication
function checkAuth() {
    if (!localStorage.getItem('isLoggedIn')) {
        window.location.href = 'index.html';
    }
}

// Sample book data (replace with actual database/API calls)
const books = [
    {
        id: 1,
        title: "To Kill a Mockingbird",
        author: "Harper Lee",
        isbn: "9780446310789",
        category: "Fiction",
        status: "Available",
        publishYear: 1960,
        copies: 5,
        borrowedCopies: 2
    },
    // Add more sample books
];

// Initialize library page
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    initializeSidebar();
    loadBooks();
    initializeFilters();
    initializeSearch();
    updateStats();
    setupEventListeners();
});

// Load books into grid
function loadBooks(filters = {}) {
    const booksGrid = document.getElementById('booksGrid');
    if (!booksGrid) return;

    let filteredBooks = [...books];

    // Apply filters
    if (filters.category) {
        filteredBooks = filteredBooks.filter(book => book.category === filters.category);
    }
    if (filters.status) {
        filteredBooks = filteredBooks.filter(book => book.status === filters.status);
    }
    if (filters.search) {
        const searchTerm = filters.search.toLowerCase();
        filteredBooks = filteredBooks.filter(book => 
            book.title.toLowerCase().includes(searchTerm) ||
            book.author.toLowerCase().includes(searchTerm) ||
            book.isbn.includes(searchTerm)
        );
    }

    // Apply sorting
    if (filters.sortBy) {
        filteredBooks.sort((a, b) => {
            const aValue = a[filters.sortBy];
            const bValue = b[filters.sortBy];
            const order = filters.sortOrder === 'desc' ? -1 : 1;
            
            return aValue > bValue ? order : -order;
        });
    }

    // Render books
    booksGrid.innerHTML = filteredBooks.map(book => `
        <div class="col-md-4 mb-4">
            <div class="card book-card h-100">
                <div class="status-badge badge bg-${getStatusColor(book.status)}">
                    ${book.status}
                </div>
                <div class="card-body">
                    <h5 class="card-title">${book.title}</h5>
                    <p class="card-text">
                        <small class="text-muted">
                            <i class="fas fa-user me-1"></i>${book.author}
                        </small>
                    </p>
                    <p class="card-text">
                        <small class="text-muted">
                            <i class="fas fa-barcode me-1"></i>${book.isbn}
                        </small>
                    </p>
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <button class="btn btn-sm btn-primary" onclick="viewBookDetails(${book.id})">
                            <i class="fas fa-info-circle me-1"></i>Details
                        </button>
                        ${book.status === 'Available' ? `
                            <button class="btn btn-sm btn-success" onclick="borrowBook(${book.id})">
                                <i class="fas fa-book me-1"></i>Borrow
                            </button>
                        ` : ''}
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

// Initialize filters
function initializeFilters() {
    // Populate category filter
    const categories = [...new Set(books.map(book => book.category))];
    const categoryFilter = document.getElementById('categoryFilter');
    if (categoryFilter) {
        categoryFilter.innerHTML += categories.map(category => 
            `<option value="${category}">${category}</option>`
        ).join('');
    }

    // Populate status filter
    const statuses = [...new Set(books.map(book => book.status))];
    const statusFilter = document.getElementById('statusFilter');
    if (statusFilter) {
        statusFilter.innerHTML += statuses.map(status => 
            `<option value="${status}">${status}</option>`
        ).join('');
    }

    // Add filter change listeners
    const filters = ['categoryFilter', 'statusFilter', 'sortBy', 'sortOrder'];
    filters.forEach(filterId => {
        document.getElementById(filterId)?.addEventListener('change', () => {
            applyFilters();
        });
    });
}

// Initialize search functionality
function initializeSearch() {
    const searchInput = document.getElementById('searchInput');
    const searchResults = document.getElementById('searchResults');
    
    if (!searchInput || !searchResults) return;

    let debounceTimeout;

    searchInput.addEventListener('input', (e) => {
        clearTimeout(debounceTimeout);
        debounceTimeout = setTimeout(() => {
            const searchTerm = e.target.value.trim();
            
            if (searchTerm.length > 2) {
                // Filter books based on search term
                const results = books.filter(book => 
                    book.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    book.author.toLowerCase().includes(searchTerm.toLowerCase()) ||
                    book.isbn.includes(searchTerm)
                ).slice(0, 5);

                // Show results
                if (results.length > 0) {
                    searchResults.innerHTML = results.map(book => `
                        <div class="p-2 search-result" onclick="selectBook(${book.id})">
                            <div class="fw-bold">${book.title}</div>
                            <small class="text-muted">${book.author}</small>
                        </div>
                    `).join('');
                    searchResults.style.display = 'block';
                } else {
                    searchResults.style.display = 'none';
                }
            } else {
                searchResults.style.display = 'none';
            }
        }, 300);
    });

    // Close search results when clicking outside
    document.addEventListener('click', (e) => {
        if (!searchInput.contains(e.target) && !searchResults.contains(e.target)) {
            searchResults.style.display = 'none';
        }
    });
}

// Apply all filters
function applyFilters() {
    const filters = {
        category: document.getElementById('categoryFilter')?.value,
        status: document.getElementById('statusFilter')?.value,
        sortBy: document.getElementById('sortBy')?.value,
        sortOrder: document.getElementById('sortOrder')?.value,
        search: document.getElementById('searchInput')?.value
    };
    
    loadBooks(filters);
}

// Update statistics
function updateStats() {
    const stats = {
        totalBooks: books.length,
        availableBooks: books.filter(b => b.status === 'Available').length,
        borrowedBooks: books.filter(b => b.status === 'Borrowed').length,
        overdueBooks: books.filter(b => b.status === 'Overdue').length
    };

    Object.entries(stats).forEach(([key, value]) => {
        const element = document.getElementById(key);
        if (element) {
            animateNumber(element, 0, value, 1000);
        }
    });
}

// Book actions
function viewBookDetails(bookId) {
    const book = books.find(b => b.id === bookId);
    if (!book) return;

    const modal = document.getElementById('bookDetailsModal');
    if (!modal) return;

    // Update modal content
    modal.querySelector('.modal-title').textContent = book.title;
    modal.querySelector('.modal-body').innerHTML = `
        <div class="row">
            <div class="col-md-6">
                <p><strong>Author:</strong> ${book.author}</p>
                <p><strong>ISBN:</strong> ${book.isbn}</p>
                <p><strong>Category:</strong> ${book.category}</p>
                <p><strong>Status:</strong> 
                    <span class="badge bg-${getStatusColor(book.status)}">${book.status}</span>
                </p>
            </div>
            <div class="col-md-6">
                <p><strong>Publish Year:</strong> ${book.publishYear}</p>
                <p><strong>Total Copies:</strong> ${book.copies}</p>
                <p><strong>Available Copies:</strong> ${book.copies - book.borrowedCopies}</p>
                <p><strong>Borrowed Copies:</strong> ${book.borrowedCopies}</p>
            </div>
        </div>
    `;

    // Show modal
    new bootstrap.Modal(modal).show();
}

function borrowBook(bookId) {
    const book = books.find(b => b.id === bookId);
    if (!book || book.status !== 'Available') return;

    // Update book status (in real app, this would be an API call)
    book.status = 'Borrowed';
    book.borrowedCopies++;

    // Refresh display
    applyFilters();
    updateStats();

    // Show success message
    showToast('Book borrowed successfully!', 'success');
}

// Utility functions
function getStatusColor(status) {
    switch (status) {
        case 'Available': return 'success';
        case 'Borrowed': return 'warning';
        case 'Overdue': return 'danger';
        default: return 'secondary';
    }
}

function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type} border-0`;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'assertive');
    toast.setAttribute('aria-atomic', 'true');
    
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    const container = document.createElement('div');
    container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
    container.appendChild(toast);
    document.body.appendChild(container);
    
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    
    toast.addEventListener('hidden.bs.toast', () => {
        container.remove();
    });
}

function animateNumber(element, start, end, duration) {
    let current = start;
    const range = end - start;
    const increment = end > start ? 1 : -1;
    const stepTime = Math.abs(Math.floor(duration / range));
    
    const timer = setInterval(() => {
        current += increment;
        element.textContent = current.toLocaleString();
        
        if (current === end) {
            clearInterval(timer);
        }
    }, stepTime);
}

// Event listeners
function setupEventListeners() {
    // Add book form submission
    const addBookForm = document.getElementById('addBookForm');
    addBookForm?.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Get form data
        const formData = new FormData(addBookForm);
        const newBook = {
            id: books.length + 1,
            title: formData.get('title'),
            author: formData.get('author'),
            isbn: formData.get('isbn'),
            category: formData.get('category'),
            publishYear: parseInt(formData.get('publishYear')),
            copies: parseInt(formData.get('copies')),
            status: 'Available',
            borrowedCopies: 0
        };
        
        // Add book (in real app, this would be an API call)
        books.push(newBook);
        
        // Close modal and refresh display
        bootstrap.Modal.getInstance(document.getElementById('addBookModal')).hide();
        addBookForm.reset();
        applyFilters();
        updateStats();
        
        // Show success message
        showToast('Book added successfully!', 'success');
    });
}

// Initialize sidebar
function initializeSidebar() {
    const sidebar = document.getElementById('sidebar');
    const sidebarCollapse = document.getElementById('sidebarCollapse');
    
    sidebarCollapse?.addEventListener('click', () => {
        sidebar?.classList.toggle('active');
    });
}
