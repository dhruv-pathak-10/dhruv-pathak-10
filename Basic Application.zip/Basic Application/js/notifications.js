// Mock notifications data
const notifications = [
    {
        id: 1,
        type: 'info',
        title: 'New Library Books',
        message: '10 new books have been added to the library collection',
        timestamp: new Date('2025-01-28T10:30:00'),
        read: false
    },
    {
        id: 2,
        type: 'warning',
        title: 'Fee Payment Due',
        message: 'Reminder: School fees payment deadline is approaching',
        timestamp: new Date('2025-01-28T09:15:00'),
        read: false
    },
    {
        id: 3,
        type: 'success',
        title: 'Grade Update',
        message: 'New grades have been posted for Mathematics',
        timestamp: new Date('2025-01-28T08:45:00'),
        read: true
    }
];

// Initialize notifications
document.addEventListener('DOMContentLoaded', () => {
    initializeNotifications();
    updateNotificationBadge();
});

// Initialize notifications dropdown
function initializeNotifications() {
    // Add notification bell to navbar if it doesn't exist
    let notificationBell = document.querySelector('.notification-bell');
    if (!notificationBell) {
        const navbar = document.querySelector('.navbar .container-fluid');
        if (navbar) {
            const bellHtml = `
                <div class="notification-bell ms-auto me-3">
                    <div class="dropdown">
                        <button class="btn btn-link position-relative" data-bs-toggle="dropdown">
                            <i class="fas fa-bell fs-5"></i>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger notification-count">
                                0
                            </span>
                        </button>
                        <div class="dropdown-menu dropdown-menu-end notification-dropdown" style="width: 300px;">
                            <div class="d-flex justify-content-between align-items-center p-3 border-bottom">
                                <h6 class="mb-0">Notifications</h6>
                                <button class="btn btn-link btn-sm text-decoration-none" onclick="markAllAsRead()">
                                    Mark all as read
                                </button>
                            </div>
                            <div class="notification-list" style="max-height: 300px; overflow-y: auto;">
                                <!-- Notifications will be loaded here -->
                            </div>
                            <div class="p-2 border-top text-center">
                                <a href="#" class="text-decoration-none">View all notifications</a>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            navbar.insertAdjacentHTML('beforeend', bellHtml);
        }
    }

    // Load notifications
    loadNotifications();
}

// Load notifications into dropdown
function loadNotifications() {
    const notificationList = document.querySelector('.notification-list');
    if (!notificationList) return;

    notificationList.innerHTML = '';
    
    if (notifications.length === 0) {
        notificationList.innerHTML = `
            <div class="text-center p-3 text-muted">
                <i class="fas fa-bell-slash mb-2"></i>
                <p class="mb-0">No notifications</p>
            </div>
        `;
        return;
    }

    notifications.sort((a, b) => b.timestamp - a.timestamp)
        .forEach(notification => {
            const notificationItem = document.createElement('div');
            notificationItem.className = `notification-item p-3 border-bottom ${notification.read ? 'read' : 'unread'}`;
            notificationItem.innerHTML = `
                <div class="d-flex align-items-center">
                    <div class="notification-icon me-3">
                        <i class="fas fa-${getNotificationIcon(notification.type)} text-${getNotificationColor(notification.type)}"></i>
                    </div>
                    <div class="notification-content flex-grow-1">
                        <div class="d-flex justify-content-between align-items-center mb-1">
                            <h6 class="mb-0">${notification.title}</h6>
                            <small class="text-muted">${formatTimestamp(notification.timestamp)}</small>
                        </div>
                        <p class="mb-0 small">${notification.message}</p>
                    </div>
                </div>
            `;
            
            notificationItem.addEventListener('click', () => {
                markAsRead(notification.id);
            });
            
            notificationList.appendChild(notificationItem);
        });
}

// Update notification badge count
function updateNotificationBadge() {
    const unreadCount = notifications.filter(n => !n.read).length;
    const badge = document.querySelector('.notification-count');
    if (badge) {
        badge.textContent = unreadCount;
        badge.style.display = unreadCount > 0 ? 'block' : 'none';
    }
}

// Mark a notification as read
function markAsRead(notificationId) {
    const notification = notifications.find(n => n.id === notificationId);
    if (notification && !notification.read) {
        notification.read = true;
        loadNotifications();
        updateNotificationBadge();
    }
}

// Mark all notifications as read
function markAllAsRead() {
    notifications.forEach(notification => {
        notification.read = true;
    });
    loadNotifications();
    updateNotificationBadge();
}

// Add new notification
function addNotification(notification) {
    notifications.unshift({
        id: notifications.length + 1,
        timestamp: new Date(),
        read: false,
        ...notification
    });
    loadNotifications();
    updateNotificationBadge();
    showNotificationToast(notification);
}

// Show notification toast
function showNotificationToast(notification) {
    // Create toast container if it doesn't exist
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container position-fixed bottom-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }

    // Create toast
    const toastElement = document.createElement('div');
    toastElement.className = 'toast';
    toastElement.innerHTML = `
        <div class="toast-header">
            <i class="fas fa-${getNotificationIcon(notification.type)} text-${getNotificationColor(notification.type)} me-2"></i>
            <strong class="me-auto">${notification.title}</strong>
            <small class="text-muted">just now</small>
            <button type="button" class="btn-close" data-bs-dismiss="toast"></button>
        </div>
        <div class="toast-body">
            ${notification.message}
        </div>
    `;

    toastContainer.appendChild(toastElement);
    const toast = new bootstrap.Toast(toastElement);
    toast.show();
}

// Utility functions
function getNotificationIcon(type) {
    const icons = {
        'info': 'info-circle',
        'warning': 'exclamation-triangle',
        'success': 'check-circle',
        'danger': 'times-circle'
    };
    return icons[type] || 'bell';
}

function getNotificationColor(type) {
    const colors = {
        'info': 'info',
        'warning': 'warning',
        'success': 'success',
        'danger': 'danger'
    };
    return colors[type] || 'primary';
}

function formatTimestamp(timestamp) {
    const now = new Date();
    const diff = now - new Date(timestamp);
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (minutes < 60) {
        return `${minutes}m ago`;
    } else if (hours < 24) {
        return `${hours}h ago`;
    } else {
        return `${days}d ago`;
    }
}

// Example: Add test notification
window.addTestNotification = () => {
    addNotification({
        type: 'info',
        title: 'Test Notification',
        message: 'This is a test notification'
    });
};
