// Mock user data (In a real application, this would be handled by a backend server)
const users = [
    {
        email: 'admin@school.com',
        password: 'admin123',
        role: 'admin',
        name: 'Admin User'
    },
    {
        email: 'teacher@school.com',
        password: 'teacher123',
        role: 'teacher',
        name: 'Teacher User'
    }
];

function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    const user = users.find(u => u.email === email && u.password === password);
    
    if (user) {
        // Store user data in sessionStorage (In a real app, use proper authentication tokens)
        sessionStorage.setItem('currentUser', JSON.stringify({
            email: user.email,
            role: user.role,
            name: user.name
        }));
        
        // Redirect to dashboard
        window.location.href = './dashboard.html';
    } else {
        alert('Invalid email or password');
    }
    
    return false;
}

// Check if user is logged in
function checkAuth() {
    const user = sessionStorage.getItem('currentUser');
    const currentPath = window.location.pathname;
    
    // If not logged in and not on login page, redirect to login
    if (!user && !currentPath.endsWith('index.html')) {
        window.location.href = './index.html';
        return;
    }
    
    // If logged in and on login page, redirect to dashboard
    if (user && currentPath.endsWith('index.html')) {
        window.location.href = './dashboard.html';
    }
}

// Logout function
function logout() {
    sessionStorage.removeItem('currentUser');
    window.location.href = './index.html';
}

// Get current user
function getCurrentUser() {
    const user = sessionStorage.getItem('currentUser');
    return user ? JSON.parse(user) : null;
}
