// Timetable Configuration and Utilities

// Time slot configuration
export const TIME_SLOTS = [
    { id: 1, start: '08:00', end: '09:00' },
    { id: 2, start: '09:00', end: '10:00' },
    { id: 3, start: '10:15', end: '11:15' },
    { id: 4, start: '11:15', end: '12:15' },
    { id: 5, start: '13:00', end: '14:00' },
    { id: 6, start: '14:00', end: '15:00' },
    { id: 7, start: '15:15', end: '16:15' }
];

// Days of the week
export const WEEKDAYS = [
    'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'
];

// Class duration in minutes
export const CLASS_DURATION = 60;

// Conflict checking utility functions
export class TimetableValidator {
    static checkRoomConflict(schedule, newClass) {
        return schedule.some(existingClass => 
            existingClass.day === newClass.day &&
            existingClass.room === newClass.room &&
            this.timeOverlaps(existingClass, newClass)
        );
    }

    static checkTeacherConflict(schedule, newClass) {
        return schedule.some(existingClass =>
            existingClass.day === newClass.day &&
            existingClass.teacher === newClass.teacher &&
            this.timeOverlaps(existingClass, newClass)
        );
    }

    static checkClassConflict(schedule, newClass) {
        return schedule.some(existingClass =>
            existingClass.day === newClass.day &&
            existingClass.class === newClass.class &&
            this.timeOverlaps(existingClass, newClass)
        );
    }

    static timeOverlaps(class1, class2) {
        const start1 = this.timeToMinutes(class1.startTime);
        const end1 = this.timeToMinutes(class1.endTime);
        const start2 = this.timeToMinutes(class2.startTime);
        const end2 = this.timeToMinutes(class2.endTime);

        return (start1 < end2 && end1 > start2);
    }

    static timeToMinutes(time) {
        const [hours, minutes] = time.split(':').map(Number);
        return hours * 60 + minutes;
    }

    static validateSchedule(schedule, newClass) {
        const conflicts = {
            hasConflict: false,
            roomConflict: false,
            teacherConflict: false,
            classConflict: false,
            message: []
        };

        if (this.checkRoomConflict(schedule, newClass)) {
            conflicts.hasConflict = true;
            conflicts.roomConflict = true;
            conflicts.message.push(`Room ${newClass.room} is already occupied at this time`);
        }

        if (this.checkTeacherConflict(schedule, newClass)) {
            conflicts.hasConflict = true;
            conflicts.teacherConflict = true;
            conflicts.message.push(`Teacher ${newClass.teacher} is already teaching at this time`);
        }

        if (this.checkClassConflict(schedule, newClass)) {
            conflicts.hasConflict = true;
            conflicts.classConflict = true;
            conflicts.message.push(`Class ${newClass.class} already has a lesson at this time`);
        }

        return conflicts;
    }
}

// Timetable generator utility
export class TimetableGenerator {
    static generateTimeSlots() {
        return TIME_SLOTS.map(slot => ({
            id: slot.id,
            time: `${slot.start} - ${slot.end}`
        }));
    }

    static generateEmptyTimetable() {
        const timetable = {};
        WEEKDAYS.forEach(day => {
            timetable[day] = TIME_SLOTS.map(slot => ({
                ...slot,
                subject: null,
                teacher: null,
                room: null,
                class: null
            }));
        });
        return timetable;
    }

    static generateClassTimetable(schedule, className) {
        const timetable = this.generateEmptyTimetable();
        schedule.forEach(lesson => {
            if (lesson.class === className) {
                const timeSlot = TIME_SLOTS.find(slot => 
                    slot.start === lesson.startTime
                );
                if (timeSlot) {
                    timetable[lesson.day][timeSlot.id - 1] = {
                        ...timeSlot,
                        subject: lesson.subject,
                        teacher: lesson.teacher,
                        room: lesson.room
                    };
                }
            }
        });
        return timetable;
    }

    static generateTeacherTimetable(schedule, teacherName) {
        const timetable = this.generateEmptyTimetable();
        schedule.forEach(lesson => {
            if (lesson.teacher === teacherName) {
                const timeSlot = TIME_SLOTS.find(slot => 
                    slot.start === lesson.startTime
                );
                if (timeSlot) {
                    timetable[lesson.day][timeSlot.id - 1] = {
                        ...timeSlot,
                        subject: lesson.subject,
                        class: lesson.class,
                        room: lesson.room
                    };
                }
            }
        });
        return timetable;
    }

    static generateRoomTimetable(schedule, roomNumber) {
        const timetable = this.generateEmptyTimetable();
        schedule.forEach(lesson => {
            if (lesson.room === roomNumber) {
                const timeSlot = TIME_SLOTS.find(slot => 
                    slot.start === lesson.startTime
                );
                if (timeSlot) {
                    timetable[lesson.day][timeSlot.id - 1] = {
                        ...timeSlot,
                        subject: lesson.subject,
                        teacher: lesson.teacher,
                        class: lesson.class
                    };
                }
            }
        });
        return timetable;
    }
}
