// Import timetable configuration and utilities
import { TIME_SLOTS, WEEKDAYS, TimetableValidator, TimetableGenerator } from './timetableConfig.js';

class TimetableManager {
    constructor() {
        this.schedule = [];
        this.currentView = {
            type: 'class',
            target: null
        };
        
        this.initializeEventListeners();
        this.loadData();
    }

    initializeEventListeners() {
        // View type change handler
        document.getElementById('viewType').addEventListener('change', (e) => {
            this.currentView.type = e.target.value;
            this.updateViewSelect();
        });

        // View select change handler
        document.getElementById('viewSelect').addEventListener('change', (e) => {
            this.currentView.target = e.target.value;
            this.renderTimetable();
        });

        // Initialize modal dropdowns
        this.initializeModalDropdowns();
    }

    initializeModalDropdowns() {
        // Populate days dropdown
        const daySelect = document.getElementById('classDay');
        WEEKDAYS.forEach(day => {
            const option = document.createElement('option');
            option.value = day;
            option.textContent = day;
            daySelect.appendChild(option);
        });

        // Populate time slots
        const timeSelect = document.getElementById('classTime');
        TIME_SLOTS.forEach(slot => {
            const option = document.createElement('option');
            option.value = slot.start;
            option.textContent = `${slot.start} - ${slot.end}`;
            timeSelect.appendChild(option);
        });

        // Load other dropdowns from data
        this.loadDropdownData();
    }

    async loadDropdownData() {
        try {
            // In a real application, these would be loaded from the server
            const subjects = ['Mathematics', 'Science', 'English', 'History', 'Geography'];
            const teachers = ['Mr. Smith', 'Mrs. Johnson', 'Ms. Davis', 'Mr. Wilson'];
            const classes = ['Class 10A', 'Class 10B', 'Class 11A', 'Class 11B'];
            const rooms = ['Room 101', 'Room 102', 'Room 103', 'Room 104'];

            this.populateDropdown('classSubject', subjects);
            this.populateDropdown('classTeacher', teachers);
            this.populateDropdown('className', classes);
            this.populateDropdown('classRoom', rooms);
            this.populateDropdown('viewSelect', this.getViewOptions());
        } catch (error) {
            console.error('Error loading dropdown data:', error);
            alert('Error loading data. Please try again.');
        }
    }

    populateDropdown(elementId, options) {
        const select = document.getElementById(elementId);
        select.innerHTML = '<option value="">Select...</option>';
        options.forEach(option => {
            const optionElement = document.createElement('option');
            optionElement.value = option;
            optionElement.textContent = option;
            select.appendChild(optionElement);
        });
    }

    getViewOptions() {
        switch (this.currentView.type) {
            case 'class':
                return ['Class 10A', 'Class 10B', 'Class 11A', 'Class 11B'];
            case 'teacher':
                return ['Mr. Smith', 'Mrs. Johnson', 'Ms. Davis', 'Mr. Wilson'];
            case 'room':
                return ['Room 101', 'Room 102', 'Room 103', 'Room 104'];
            default:
                return [];
        }
    }

    updateViewSelect() {
        this.populateDropdown('viewSelect', this.getViewOptions());
        this.currentView.target = null;
        this.renderTimetable();
    }

    async loadData() {
        try {
            // In a real application, this would load from a server
            // For now, we'll use mock data
            this.schedule = [
                {
                    day: 'Monday',
                    startTime: '08:00',
                    endTime: '09:00',
                    subject: 'Mathematics',
                    teacher: 'Mr. Smith',
                    class: 'Class 10A',
                    room: 'Room 101'
                },
                // Add more mock schedule entries as needed
            ];
            
            this.renderTimetable();
        } catch (error) {
            console.error('Error loading timetable data:', error);
            alert('Error loading timetable. Please try again.');
        }
    }

    renderTimetable() {
        const container = document.getElementById('timetableContainer');
        if (!this.currentView.target) {
            container.innerHTML = '<div class="alert alert-info">Please select a view target</div>';
            return;
        }

        let timetable;
        switch (this.currentView.type) {
            case 'class':
                timetable = TimetableGenerator.generateClassTimetable(this.schedule, this.currentView.target);
                break;
            case 'teacher':
                timetable = TimetableGenerator.generateTeacherTimetable(this.schedule, this.currentView.target);
                break;
            case 'room':
                timetable = TimetableGenerator.generateRoomTimetable(this.schedule, this.currentView.target);
                break;
        }

        this.renderTimetableHTML(timetable);
    }

    renderTimetableHTML(timetable) {
        const container = document.getElementById('timetableContainer');
        let html = '<div class="table-responsive"><table class="table table-bordered">';
        
        // Header row
        html += '<thead><tr><th>Time</th>';
        WEEKDAYS.forEach(day => {
            html += `<th>${day}</th>`;
        });
        html += '</tr></thead><tbody>';

        // Time slots
        TIME_SLOTS.forEach(slot => {
            html += `<tr><td>${slot.start} - ${slot.end}</td>`;
            WEEKDAYS.forEach(day => {
                const lesson = timetable[day][slot.id - 1];
                if (lesson.subject) {
                    html += `
                        <td class="timetable-cell occupied">
                            <strong>${lesson.subject}</strong><br>
                            ${this.currentView.type !== 'teacher' ? `Teacher: ${lesson.teacher}<br>` : ''}
                            ${this.currentView.type !== 'class' ? `Class: ${lesson.class}<br>` : ''}
                            ${this.currentView.type !== 'room' ? `Room: ${lesson.room}` : ''}
                        </td>
                    `;
                } else {
                    html += '<td class="timetable-cell"></td>';
                }
            });
            html += '</tr>';
        });

        html += '</tbody></table></div>';
        container.innerHTML = html;
    }

    async saveClass() {
        const newClass = {
            day: document.getElementById('classDay').value,
            startTime: document.getElementById('classTime').value,
            endTime: this.getEndTime(document.getElementById('classTime').value),
            subject: document.getElementById('classSubject').value,
            teacher: document.getElementById('classTeacher').value,
            class: document.getElementById('className').value,
            room: document.getElementById('classRoom').value
        };

        // Validate all fields are filled
        if (Object.values(newClass).some(value => !value)) {
            alert('Please fill all fields');
            return;
        }

        // Check for conflicts
        const conflicts = TimetableValidator.validateSchedule(this.schedule, newClass);
        if (conflicts.hasConflict) {
            alert('Conflicts detected:\n' + conflicts.message.join('\n'));
            return;
        }

        try {
            // In a real application, this would save to a server
            this.schedule.push(newClass);
            
            // Close modal and refresh
            $('#addClassModal').modal('hide');
            document.getElementById('addClassForm').reset();
            this.renderTimetable();
            
            alert('Class added successfully!');
        } catch (error) {
            console.error('Error saving class:', error);
            alert('Error saving class. Please try again.');
        }
    }

    getEndTime(startTime) {
        const slot = TIME_SLOTS.find(slot => slot.start === startTime);
        return slot ? slot.end : '';
    }

    exportTimetable() {
        if (!this.currentView.target) {
            alert('Please select a view target first');
            return;
        }

        let timetable;
        switch (this.currentView.type) {
            case 'class':
                timetable = TimetableGenerator.generateClassTimetable(this.schedule, this.currentView.target);
                break;
            case 'teacher':
                timetable = TimetableGenerator.generateTeacherTimetable(this.schedule, this.currentView.target);
                break;
            case 'room':
                timetable = TimetableGenerator.generateRoomTimetable(this.schedule, this.currentView.target);
                break;
        }

        const csv = this.generateCSV(timetable);
        const blob = new Blob([csv], { type: 'text/csv' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `timetable_${this.currentView.type}_${this.currentView.target}.csv`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    }

    generateCSV(timetable) {
        let csv = 'Time,';
        csv += WEEKDAYS.join(',') + '\n';

        TIME_SLOTS.forEach(slot => {
            csv += `${slot.start} - ${slot.end},`;
            WEEKDAYS.forEach(day => {
                const lesson = timetable[day][slot.id - 1];
                if (lesson.subject) {
                    csv += `${lesson.subject} (${lesson.teacher}, ${lesson.room})`;
                }
                csv += ',';
            });
            csv += '\n';
        });

        return csv;
    }
}

// Initialize timetable manager
const timetableManager = new TimetableManager();

// Export functions for global access
window.saveClass = () => timetableManager.saveClass();
window.exportTimetable = () => timetableManager.exportTimetable();
